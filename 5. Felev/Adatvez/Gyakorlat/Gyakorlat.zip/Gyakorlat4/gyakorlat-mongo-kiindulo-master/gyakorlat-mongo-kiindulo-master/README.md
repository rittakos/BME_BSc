# BME Adatvezérelt rendszerek / BME Data-driven systems

Kiinduló kód a MongoDB gyakorlathoz.

Starter code for the MongoDB seminar.