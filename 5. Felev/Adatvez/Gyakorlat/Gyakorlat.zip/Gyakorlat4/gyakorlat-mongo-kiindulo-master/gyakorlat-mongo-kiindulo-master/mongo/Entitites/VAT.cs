namespace BME.DataDriven.Mongo.Entitites
{
    public class VAT
    {
        public string Name { get; set; }
        public int? Percentage { get; set; }
    }
}
