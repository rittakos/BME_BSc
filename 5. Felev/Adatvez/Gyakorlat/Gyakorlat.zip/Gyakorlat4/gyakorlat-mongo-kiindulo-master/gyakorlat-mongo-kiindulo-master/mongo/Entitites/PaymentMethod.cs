namespace BME.DataDriven.Mongo.Entitites
{
    public class PaymentMethod
    {
        public string Method { get; set; }
        public int? Deadline { get; set; }
    }
}
