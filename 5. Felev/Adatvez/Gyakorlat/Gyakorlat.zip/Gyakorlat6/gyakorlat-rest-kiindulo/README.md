# BME Adatvezérelt rendszerek / BME Data-driven systems

Kiinduló kód a REST gyakorlathoz.

Starter code for the REST seminar.