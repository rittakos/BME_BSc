﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BME.DataDriven.REST.Controllers
{
    [Route("api/hello")]
    [ApiController]
    public class HelloController : ControllerBase
    {
        // 2. alfeladat
        //[HttpGet]
        //public ActionResult<string> Hello()
        //{
        //    return "Hello!";
        //}

        // 3. alfeladat
        [HttpGet]
        public ActionResult<string> Hello([FromQuery] string name)
        {
            if (string.IsNullOrEmpty(name))
                return "Hello noname!";
            else
                return "Hello " + name;
        }

        // 4. alfeladat
        [HttpGet]
        [Route("{personName}")] // a route-ban a {} közötti név meg kell egyezzen a paraméter nevével
        public ActionResult<string> HelloRoute(string personName)
        {
            return "Hello " + personName;
            //return "Hello route " + personName;
        }
    }
}
