﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BME.DataDriven.REST.Controllers
{
    [Route("api/products")] // adjunk meg explicit urlt inkabb
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly Dal.DataDrivenDbContext dbContext;

        // Az adatbazist igy kaphatjuk meg. A kornyezet adja a Dependency Injection szolgaltatast.
        // A DbContext automatikusan megszunik a keres veges (DI beallitas).
        public ProductsController(Dal.DataDrivenDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public ActionResult<Model.Product[]> List([FromQuery] string search = null, [FromQuery] int from = 0)
        {
            IQueryable<Dal.Product> filteredList;

            if (string.IsNullOrEmpty(search)) // ha nincs nev alapu kereses, az osszes termek
                filteredList = dbContext.Product;
            else // nev alapjan kereses
                filteredList = dbContext.Product.Where(p => p.Name.Contains(search));

            return filteredList
                    .Skip(from) // lapozashoz: hanyadik termektol kezdve
                    .Take(5) // egy lapon max 5 termek
                    .Select(p => new Model.Product(p.Id, p.Name, p.Price, p.Stock)) // adatbazis entitas -> DTO
                    .ToArray(); // a fenti IQueryable kiertekelesesen kieroltetese, kulonben hibara futnank
        }

        // GET api/products/id
        [HttpGet]
        [Route("{id}")]
        public ActionResult<Model.Product> Get(int id)
        {
            var dbProduct = dbContext.Product.SingleOrDefault(p => p.Id == id);

            if (dbProduct == null)
                return NotFound(); // helyes http valasz, ha nem talalhato a keresett elem
            else
                return new Model.Product(dbProduct.Id, dbProduct.Name, dbProduct.Price, dbProduct.Stock); // siker eseten visszaadjuk az adatot magat
        }

        // PUT api/products/id
        [HttpPut]
        [Route("{id}")]
        public ActionResult Modify([FromRoute] int id, [FromBody] Model.Product updated)
        {
            if (id != updated.Id)
                return BadRequest();

            var dbProduct = dbContext.Product.SingleOrDefault(p => p.Id == id);

            if (dbProduct == null)
                return NotFound();

            // modositasok elvegzese
            dbProduct.Name = updated.Name;
            dbProduct.Price = updated.Price;
            dbProduct.Stock = updated.Stock;

            // mentes az adatbazisban
            dbContext.SaveChanges();

            return NoContent(); // 204 NoContent valasz
        }

        // POST api/products
        [HttpPost]
        public ActionResult Create([FromBody] Model.NewProduct newProduct)
        {
            var dbVat = dbContext.Vat.FirstOrDefault(v => v.Percentage == newProduct.VATPercentage);
            if (dbVat == null)
                dbVat = new Dal.VAT() { Percentage = newProduct.VATPercentage };

            var dbCat = dbContext.Category.FirstOrDefault(c => c.Name == newProduct.CategoryName);
            if (dbCat == null)
                dbCat = new Dal.Category() { Name = newProduct.CategoryName };

            var dbProduct = new Dal.Product()
            {
                Name = newProduct.Name,
                Price = newProduct.Price,
                Stock = newProduct.Stock,
                Category = dbCat,
                VAT = dbVat
            };

            // mentes az adatbazisba
            dbContext.Product.Add(dbProduct);
            dbContext.SaveChanges();

            return CreatedAtAction(nameof(Get), new { id = dbProduct.Id }, new Model.Product(dbProduct.Id, dbProduct.Name, dbProduct.Price, dbProduct.Stock)); // igy mondjuk meg, hol kerdezheto le a beszurt elem
        }

        // DELETE api/products/id
        [HttpDelete]
        [Route("{id}")]
        public ActionResult Delete(int id)
        {
            var dbProduct = dbContext.Product.SingleOrDefault(p => p.Id == id);

            if (dbProduct == null)
                return NotFound();

            dbContext.Product.Remove(dbProduct);
            dbContext.SaveChanges();

            return NoContent(); // a sikeres torlest 204 NoContent valasszal jelezzuk (lehetne meg 200 OK is, ha beletennenk an entitast)
        }


    }
}
