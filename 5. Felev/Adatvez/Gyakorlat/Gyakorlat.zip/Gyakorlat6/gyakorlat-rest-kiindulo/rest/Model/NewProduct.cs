﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BME.DataDriven.REST.Model
{
    public class NewProduct
    {
        public NewProduct(string name, double? price, int? stock, int perc, string catName)
        {
            Name = name;
            Price = price;
            Stock = stock;
            VATPercentage = perc;
            CategoryName = catName;
        }

        public string Name { get; private set; }
        public double? Price { get; private set; }
        public int? Stock { get; private set; }
        public int VATPercentage { get; private set; }
        public string CategoryName { get; private set; }
    }
}
