﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BME.DataDriven.REST.Model
{
    public class Product
    {
        public Product(int id, string name, double? price, int? stock)
        {
            Id = id;
            Name = name;
            Price = price;
            Stock = stock;
        }

        // Csak a lenyeges tulajdonsagokat tartalmazza, pl. az adatbazis kulso kulcsokat nem.
        // Ertekadas csak a konstruktoron keresztul lehetseges, ezzel jelezve, hogy a peldany
        // egy pillanatkep alapjan jon letre, es nem modosithato.

        public int Id { get; private set; }
        public string Name { get; private set; }
        public double? Price { get; private set; }
        public int? Stock { get; private set; }
    }
}
