﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ef
{
    [Table("Product")]
    public class DbProduct
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }

        [ForeignKey("VATID")]
        public DbVat Vat { get; set; }
    }
}