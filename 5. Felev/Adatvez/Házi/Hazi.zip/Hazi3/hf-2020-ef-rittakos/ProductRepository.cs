﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ef
{
    public class ProductRepository
    {
        private readonly string connectionString;

        // Do not change the constructor
        public ProductRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }

        // Do not change this method
        private ProductDbContext createDbContext()
        {
            var contextOptionsBuilder = new DbContextOptionsBuilder<ProductDbContext>();
            contextOptionsBuilder.UseSqlServer(connectionString);
            return new ProductDbContext(contextOptionsBuilder.Options);
        }


        public IReadOnlyCollection<Product> List()
        {
            using (var db = createDbContext())
            {
                // ...
            }
            throw new System.NotImplementedException();
        }

        public void Insert(Product value)
        {
            throw new System.NotImplementedException();
        }
    }
}
