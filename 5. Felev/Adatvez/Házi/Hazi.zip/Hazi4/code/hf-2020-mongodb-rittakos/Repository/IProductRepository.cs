﻿using MongoDB.Bson;

namespace mongo
{
    public interface IProductRepository
    {
        void ChangeVatPercentage(string name, int newPercentage);
        (string, double?) ProductWithLargestTotalValue(ObjectId categoryId);
    }
}
