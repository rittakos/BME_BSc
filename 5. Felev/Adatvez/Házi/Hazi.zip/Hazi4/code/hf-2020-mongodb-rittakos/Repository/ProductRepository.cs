﻿using System;
using mongo.Entitites;
using MongoDB.Bson;
using MongoDB.Driver;

namespace mongo
{
    public class ProductRepository : IProductRepository
    {
        private readonly IMongoCollection<Product> productCollection;

        // Keep the constructor and the field as-is
        public ProductRepository(IMongoDatabase database)
        {
            this.productCollection = database.GetCollection<Product>("products");
        }

        public void ChangeVatPercentage(string name, int newPercentage)
        {
            productCollection.UpdateMany(   filter: x => x.VAT.Name == name,
                                            update: Builders<Product>.Update.Set(x => x.VAT.Percentage, newPercentage));
        }

        public (string, double?) ProductWithLargestTotalValue(ObjectId categoryId)
        {
            throw new NotImplementedException();
        }
    }
}
