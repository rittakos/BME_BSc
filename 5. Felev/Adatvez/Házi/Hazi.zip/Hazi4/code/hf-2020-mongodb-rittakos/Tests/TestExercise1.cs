﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MongoDB.Driver;

namespace mongo.Tests
{
    [TestClass]
    public class TestExercise1
    {
        [TestMethod]
        public void Ex1()
        {
            var vatName = "Standard Rate";
            var currentPercentage = TestDbFactory.ProductCollection
                .Find(p => p.VAT.Name == vatName)
                .Project(p => p.VAT.Percentage)
                .First();
            var newPercentage = currentPercentage.Value + 1;

            var repo = new ProductRepository(TestDbFactory.Database);
            repo.ChangeVatPercentage(vatName, newPercentage);

            var newPercentageValuesFromProduct = TestDbFactory.ProductCollection
                .Find(p => p.VAT.Name == vatName)
                .Project(p => p.VAT.Percentage)
                .ToEnumerable()
                .Distinct()
                .ToList();

            Assert.AreEqual(1, newPercentageValuesFromProduct.Count);
            Assert.AreEqual(newPercentage, newPercentageValuesFromProduct.First());
        }
    }
}
