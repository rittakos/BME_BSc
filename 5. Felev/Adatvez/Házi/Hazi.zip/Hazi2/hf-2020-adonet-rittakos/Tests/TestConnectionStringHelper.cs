﻿namespace adonet
{
    public static class TestConnectionStringHelper
    {
        public static string SqlConnectionString
        {
            // you may edit the connection string here
            //get { return @"data source=(localdb)\mssqllocaldb;initial catalog=adatvez;integrated security=true"; }
            get { return @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=Z8WK8D;Integrated Security=True"; }
            
        }
    }
}
