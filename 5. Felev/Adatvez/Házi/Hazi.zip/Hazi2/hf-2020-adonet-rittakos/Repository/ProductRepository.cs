﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace adonet
{
    // The class must implement this interface, do not change.
    public class ProductRepository : IProductRepository
    {
        private readonly string connectionString;

        // Keep the constructor and the member as-is.
        public ProductRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public IReadOnlyList<Product> Search(string name)
        {
            var result = new List<Product>();
            using (var conn = new SqlConnection(connectionString))
            {

                
                var command = new SqlCommand();
                command.Connection = conn;
                if (name == null)
                {
                    command.CommandText = @"SELECT p.ID, p.Name, p.Price, p.Stock, c.Name as cName, v.Percentage FROM Product p 
                                            JOIN Category c ON p.CategoryID = c.ID
                                            JOIN VAT v ON p.VATID = v.ID
                                            ";
                }
                else
                {
                    command.CommandText = @"SELECT p.ID, p.Name, p.Price, p.Stock, c.Name as cName, v.Percentage FROM Product p 
                                            JOIN Category c ON p.CategoryID = c.ID
                                            JOIN VAT v ON p.VATID = v.ID
                                            WHERE CHARINDEX(@Name, p.Name) != 0";
                    var parameter = new SqlParameter();
                    parameter.ParameterName = "@Name";
                    parameter.SqlDbType = System.Data.SqlDbType.NVarChar;
                    parameter.Value = name;


                    command.Parameters.Add(parameter);
                }


                conn.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new Product((int)reader["ID"], (string)reader["Name"], (double)reader["Price"], (int)reader["Stock"], (int)reader["Percentage"], (string)reader["cName"]));   
                    }
                }   
                    
                conn.Close();
            }
            return result;
        }

        public Product FindById(int id)
        {
            using (var conn = new SqlConnection(connectionString))
            {


                var command = new SqlCommand();
                command.Connection = conn;
                
                command.CommandText = @"SELECT p.ID, p.Name, p.Price, p.Stock, c.Name as cName, v.Percentage FROM Product p 
                                            JOIN Category c ON p.CategoryID = c.ID
                                            JOIN VAT v ON p.VATID = v.ID
                                            WHERE p.ID = @id";
                var parameter = new SqlParameter();
                parameter.ParameterName = "@id";
                parameter.SqlDbType = System.Data.SqlDbType.NVarChar;
                parameter.Value = id;


                command.Parameters.Add(parameter);
                


                conn.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return new Product((int)reader["ID"], (string)reader["Name"], (double)reader["Price"], (int)reader["Stock"], (int)reader["Percentage"], (string)reader["cName"]);
                    }
                }
                return null;
            }
        }

        public void Update(Product p)
        {
            using (var conn = new SqlConnection(connectionString))
            {


                var command = new SqlCommand();
                command.Connection = conn;

                command.CommandText = "UPDATE Product SET Name = @name, Price = @price, Stock = @stock WHERE ID = @id";
                var name = new SqlParameter();
                name.ParameterName = "@name";
                name.SqlDbType = System.Data.SqlDbType.NVarChar;
                name.Value = p.Name;

                var price = new SqlParameter();
                price.ParameterName = "@price";
                price.SqlDbType = System.Data.SqlDbType.NVarChar;
                price.Value = p.Price;

                var stock = new SqlParameter();
                stock.ParameterName = "@stock";
                stock.SqlDbType = System.Data.SqlDbType.NVarChar;
                stock.Value = p.Stock;

                var id = new SqlParameter();
                id.ParameterName = "@id";
                id.SqlDbType = System.Data.SqlDbType.NVarChar;
                id.Value = p.ID;


                command.Parameters.Add(name);
                command.Parameters.Add(price);
                command.Parameters.Add(stock);
                command.Parameters.Add(id);



                conn.Open();
                
                command.ExecuteNonQuery();

            }
        }

        public bool UpdateWithConcurrencyCheck(Product p)
        {
            throw new NotImplementedException();
        }
    }
}
