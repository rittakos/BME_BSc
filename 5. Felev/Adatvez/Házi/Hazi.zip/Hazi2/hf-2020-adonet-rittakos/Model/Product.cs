﻿namespace adonet
{
    public class Product
    {
        // Keep the constuctor arguments as-is.
        public Product(int id, string name, double price, int stock, int vatPercentage, string categoryName)
        {
            ID = id;
            Name = name;
            Price = price;
            Stock = stock;
            VatPercentage = vatPercentage;
            CategoryName = categoryName;

            // You may add code here for exercise 2.
        }


        // Keep existing properties as-is.
        public int ID { get; }
        public string Name { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }
        public int VatPercentage { get; }
        public string CategoryName { get; }

        // You may add extra properties here for exercise 2.
    }
}
