﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using webapi.DAL;
using webapi.Model;

namespace webapi.Controllers
{
    // Keep the URL as-is
    [Route("api/product")]
    public class ProductsController : Controller
    {
        private readonly IProductRepository productRepository;

        // Keep this contructor as-is
        public ProductsController(IProductRepository productRepository)
        {
            this.productRepository = productRepository;
        }

        [HttpGet]
        public IEnumerable<Product> GetAll()
        {
            return productRepository.List();
        }


        [HttpHead]
        [Route("{id}")]
        public ActionResult<int> Exist(int id)
        {
            if(productRepository.GetById(id) == null)
                return NotFound();
            return Ok();
        }

        [HttpGet]
        [Route("{id}")]
        public ActionResult<Product> GetProductByID(int id)
        {
            Product product = productRepository.GetById(id);

            if (product == null)
                return NotFound();

            return Ok(product);
        }


        [HttpGet]
        [Route("-/count")]
        public ActionResult<CountResult> CountOfTypes()
        {
            CountResult result = new CountResult();
            result.Count = productRepository.List().Count;

            return result;
        }
        // Add new api endpoints here
    }
}