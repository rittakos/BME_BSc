﻿namespace webapi.Model
{
    // Keep this class as-is
    public class CountResult
    {
        public int Count { get; set; }
    }
}
