create or alter trigger PasswordUpdate
	on Customer
	for insert, update
as
IF(UPDATE(Password))
BEGIN
	UPDATE Customer
	set PasswordExpiry = DATEADD(year, 1, GETDATE())
	from Customer c join inserted i on c.ID = i.ID
END

