import java.io.File
import java.nio.charset.Charset

fun main(args: Array<String>) {
    if (args.size !in 2..3) {
        return
    }

    val path = args[0]
    val java = args[1]
    val skipSuccess = args.size == 3 && args[2] == "skip"

    File("""$path\tests\""").walk().drop(1).filter { it.isDirectory }.forEach {
        if (!skipSuccess) {
            print("Running script: ${it.name} ...")
        }

        val desiredOutput = File(it, "output.txt").readLines()
        val process = ProcessBuilder(java, "-Dfile.encoding=UTF-8", """-classpath""", """$path\out\production\jegmezo""", """com.area51.icefield.ui.CommandController""", it.absolutePath + """\input.txt""").start()
        process.waitFor()
        process.inputStream.reader(Charset.defaultCharset()).run {
            val output = this.readLines()

            var error = false
            for (i: Int in output.indices) {
                if (desiredOutput.size <= i) {
                    if (!error && skipSuccess) {
                        print("Running script: ${it.name} ...")
                    }

                    println("\n\tError at line ${i + 1} - ran out of expected output!")
                    error = true
                    break
                } else if (output[i] != desiredOutput[i]) {
                    if (!error && skipSuccess) {
                        print("Running script: ${it.name} ...")
                    }

                    println("\n\tError at line ${i + 1} - expected: \"${desiredOutput[i]}\" got: \"${output[i]}\"")
                    error = true
                    break
                }
            }

            if (!error && !skipSuccess) {
                println(" Successful run!")
            } else if (error && skipSuccess) {
                return@main
            }
        }
    }
}
