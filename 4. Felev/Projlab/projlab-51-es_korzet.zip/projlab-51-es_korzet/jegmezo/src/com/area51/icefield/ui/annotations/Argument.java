package com.area51.icefield.ui.annotations;

import java.lang.annotation.*;

/**
 * Methods annotated with this annotation require an argument. They must be annotated with {@link Command} as well.
 */
@Repeatable(Arguments.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface Argument {
    /**
     * The name of the argument.
     *
     * @return the name of the argument
     */
    String name();

    /**
     * The base-type of the argument. When parsing input it will be converted to this types sub-type.
     *
     * @return the base-type of the argument.
     */
    Class<?> baseType();
}