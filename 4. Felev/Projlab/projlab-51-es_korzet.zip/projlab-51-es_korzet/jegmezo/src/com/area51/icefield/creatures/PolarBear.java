package com.area51.icefield.creatures;

import com.area51.icefield.map.TileReference;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A Polar bear has 1 energy, and attacks every tile it visits.
 */
@CommandArgumentType(value = "PolarBear", baseType = Creature.class)
public final class PolarBear extends Creature {
    /**
     * {@inheritDoc}
     */
    @Override
    protected int getDefaultEnergy() {
        return 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onVisit(TileReference tileReference) {
        tileReference.getTile().attack();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Type: PolarBear");

        super.dumpData(tabs);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void isInStorm() { }

    /**
     * {@inheritDoc}
     */
    @Override
    public void attacked() { }

    /**
     * {@inheritDoc}
     */
    @Override
    public void isInWater() {
        kill();
    }
}
