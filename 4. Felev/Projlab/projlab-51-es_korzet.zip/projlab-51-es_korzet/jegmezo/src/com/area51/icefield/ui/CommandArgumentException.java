package com.area51.icefield.ui;

import com.area51.icefield.ui.annotations.Argument;

/**
 * An exception thrown when a command argument error occurs.
 */
public class CommandArgumentException extends CommandException {
    /**
     * Instantiates a new CommandArgumentException
     *
     * @param argument argument of the called command.
     * @param actual   the input string
     */
    public CommandArgumentException(Argument argument, String actual) {
        super("Invalid argument '" + actual + "' expected type '" + argument.name() + "'");
    }

    /**
     * Instantiates a new CommandArgumentException
     *
     * @param argument argument of the called command.
     * @param actual   the input string
     * @param cause    the causing Throwable
     */
    public CommandArgumentException(Argument argument, String actual, Throwable cause) {
        super("Invalid argument '" + actual + "' expected type '" + argument.name() + "'", cause);
    }
}
