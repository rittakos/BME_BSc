package com.area51.icefield.ui.conversions;

/**
 * A basic String converter {@link ITypeConverter}
 */
public final class StringConverter implements ITypeConverter {
    /**
     * {@inheritDoc}
     */
    @Override
    public Object getInstanceOf(Class<?> baseType, String value) throws IllegalArgumentException {
        return value;
    }
}
