package com.area51.icefield.map;

import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A Stable ice has infinite capacity, and can contain a frozen thing.
 */
@CommandArgumentType(value = "Stable", baseType = Tile.class)
public final class StableIce extends Tile {
    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Type: Stable");

        super.dumpData(tabs);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getCapacity() {
        return -1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setCapacity(int capacity) {
        throw new UnsupportedOperationException("StableIce can not have a capacity!");
    }
}
