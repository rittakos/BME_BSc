package com.area51.icefield.ui;

import com.area51.icefield.Game;
import com.area51.icefield.GameState;
import com.area51.icefield.creatures.Creature;
import com.area51.icefield.creatures.NotEnoughEnergyException;
import com.area51.icefield.creatures.Player;
import com.area51.icefield.creatures.PolarBear;
import com.area51.icefield.map.Building;
import com.area51.icefield.map.Tile;
import com.area51.icefield.map.TileReference;
import com.area51.icefield.things.Thing;
import com.area51.icefield.ui.annotations.Argument;
import com.area51.icefield.ui.annotations.Command;
import com.area51.icefield.utils.Utils;

import java.util.HashMap;
import java.util.Map;

/**
 * Class containing all Commands
 */
public final class GameCommandController {
    private final Map<String, TileReference> tileReferenceDictionary = new HashMap<>();
    private final Map<String, Creature> creatureDictionary = new HashMap<>();

    /**
     * Dump command handler.
     */
    @Command(command = "dump", description = "Dumps all info about the game.")
    public void dumpCommandHandler() {
        System.out.println("Game state: " + Game.Instance.getGameState().toString());
        System.out.println("Creatures: [");
        for (Map.Entry<String, Creature> creatureEntry : creatureDictionary.entrySet()) {
            Utils.writeTabs(1, String.format("'%s': [", creatureEntry.getKey()));
            Utils.writeTabs(2, String.format("Standing on: '%s'", getTileReferencesKey(creatureEntry.getValue().getStandingOn())));

            creatureEntry.getValue().dumpData(2);

            Utils.writeTabs(1, "]");
        }
        System.out.println("]");

        System.out.println("Tiles: [");
        for (Map.Entry<String, TileReference> tileReferenceEntry : tileReferenceDictionary.entrySet()) {
            Utils.writeTabs(1, String.format("'%s': [", tileReferenceEntry.getKey()));

            Utils.writeTabs(2, "Creatures: [");
            for (Creature creature : tileReferenceEntry.getValue().getTile().getCreatures()) {
                Utils.writeTabs(3, getCreaturesKey(creature));
            }
            Utils.writeTabs(2, "]");

            Utils.writeTabs(2, "Neighbours: [");
            for (TileReference tileReference : tileReferenceEntry.getValue().getNeighbours()) {
                Utils.writeTabs(3, getTileReferencesKey(tileReference));
            }
            Utils.writeTabs(2, "]");

            tileReferenceEntry.getValue().getTile().dumpData(2);

            Utils.writeTabs(1, "]");
        }
        System.out.println("]");
    }

    private String getTileReferencesKey(TileReference tileReference) {
        return getKeyOfMap(tileReferenceDictionary, tileReference);
    }

    private String getCreaturesKey(Creature creature) {
        return getKeyOfMap(creatureDictionary, creature);
    }

    private <T> String getKeyOfMap(Map<String, T> collection, T match) {
        return collection.entrySet().stream().filter(
                entry -> entry.getValue() == match
        ).findFirst().map(Map.Entry::getKey).orElse(null);
    }

    /**
     * New tile command handler.
     *
     * @param tileName the tile name
     * @param tile     the tile
     *
     * @throws CommandException the command exception
     */
    @Command(command = "newtile", description = "Creates a new tile with the specified name and type.")
    @Argument(name = "tilename", baseType = String.class)
    @Argument(name = "tiletype", baseType = Tile.class)
    public void newTileCommandHandler(String tileName, Tile tile) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("New tile can only be added when the game is in Initialising state!");
        }
        if (tileReferenceDictionary.get(tileName) != null) {
            throw new CommandException("A Tile already exists with the given name!");
        }

        TileReference tileReference = tile.getTileReference();

        tileReferenceDictionary.put(tileName, tileReference);
        Game.Instance.addTileReference(tileReference);
    }

    /**
     * New polar bear command handler.
     *
     * @param creatureName the creature name
     *
     * @throws CommandException the command exception
     */
    @Command(command = "newpolarbear", description = "Creates a new Polar Bear with the specified name.")
    @Argument(name = "creaturename", baseType = String.class)
    public void newPolarBearCommandHandler(String creatureName) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("New PolarBear can only be added when the game is in Initialising state!");
        }
        if (creatureDictionary.get(creatureName) != null) {
            throw new CommandException("A Creature already exists with the given name!");
        }

        Creature creature = new PolarBear();
        creatureDictionary.put(creatureName, creature);
        Game.Instance.addCreature(creature);
    }

    /**
     * New player command handler.
     *
     * @param creatureName the creature name
     * @param player       the player
     *
     * @throws CommandException the command exception
     */
    @Command(command = "newplayer", description = "Creates a new Player with the specified name and type.")
    @Argument(name = "playername", baseType = String.class)
    @Argument(name = "playertype", baseType = Player.class)
    public void newPlayerCommandHandler(String creatureName, Player player) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("New Player can only be added when the game is in Initialising state!");
        }
        if (creatureDictionary.get(creatureName) != null) {
            throw new CommandException("A Creature already exists with the given name!");
        }

        creatureDictionary.put(creatureName, player);
        Game.Instance.addCreature(player);
    }

    /**
     * Add thing command handler.
     *
     * @param creatureName the creature name
     * @param thing        the thing
     *
     * @throws CommandException the command exception
     */
    @Command(command = "addthing", description = "Adds a specified type of thing")
    @Argument(name = "playername", baseType = String.class)
    @Argument(name = "thingtype", baseType = Thing.class)
    public void addThingCommandHandler(String creatureName, Thing thing) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("A Creature can only be added to a tile when the game is in Initialising state!");
        }
        if (creatureDictionary.get(creatureName) == null) {
            throw new CommandException("There is no Creature with the name: " + creatureName + "!");
        }

        ((Player) creatureDictionary.get(creatureName)).addThingToBackpack(thing);
    }

    /**
     * Add connection command handler.
     *
     * @param tileName1 the tile name 1
     * @param tileName2 the tile name 2
     *
     * @throws CommandException the command exception
     */
    @Command(command = "addconnection", description = "Adds a new connection between two existing tiles.")
    @Argument(name = "tilename1", baseType = String.class)
    @Argument(name = "tilename2", baseType = String.class)
    public void addConnectionCommandHandler(String tileName1, String tileName2) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("Tile connection can only be added when the game is in Initialising state!");
        }
        if (tileName1.equals(tileName2)) {
            throw new CommandException("The two tiles must be different!");
        }
        if (tileReferenceDictionary.get(tileName1) == null) {
            throw new CommandException("There is no Tile with the name: " + tileName1 + "!");
        }
        if (tileReferenceDictionary.get(tileName2) == null) {
            throw new CommandException("There is no Tile with the name: " + tileName2 + "!");
        }

        // todo: check if there is already a connection

        tileReferenceDictionary.get(tileName1).addNeighbour(tileReferenceDictionary.get(tileName2));
        tileReferenceDictionary.get(tileName2).addNeighbour(tileReferenceDictionary.get(tileName1));
    }

    /**
     * Add creature command handler.
     *
     * @param tileName     the tile name
     * @param creatureName the creature name
     *
     * @throws CommandException the command exception
     */
    @Command(command = "addcreature", description = "Adds the Specified creature to the specified Tile.")
    @Argument(name = "tilename", baseType = String.class)
    @Argument(name = "creaturename", baseType = String.class)
    public void addCreatureCommandHandler(String tileName, String creatureName) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("A Creature can only be added to a tile when the game is in Initialising state!");
        }
        if (tileReferenceDictionary.get(tileName) == null) {
            throw new CommandException("There is no Tile with the name: " + tileName + "!");
        }
        if (creatureDictionary.get(creatureName) == null) {
            throw new CommandException("There is no Creature with the name: " + creatureName + "!");
        }

        Creature creature = creatureDictionary.get(creatureName);
        TileReference tileReference = tileReferenceDictionary.get(tileName);

        tileReference.getTile().addCreature(creature);
        creature.setStandingOn(tileReference);
    }

    /**
     * Sets building command handler.
     *
     * @param tileName the tile name
     * @param building the building
     *
     * @throws CommandException the command exception
     */
    @Command(command = "setbuilding", description = "Sets the given Tile's building to the specified value.")
    @Argument(name = "tilename", baseType = String.class)
    @Argument(name = "buildingtype", baseType = Building.class)
    public void setBuildingCommandHandler(String tileName, Building building) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("A Building can only be added to a tile when the game is in Initialising state!");
        }
        if (tileReferenceDictionary.get(tileName) == null) {
            throw new CommandException("There is no Tile with the name: " + tileName + "!");
        }

        TileReference tileReference = tileReferenceDictionary.get(tileName);
        tileReference.getTile().setBuilding(building);
    }

    /**
     * Sets snow command handler.
     *
     * @param tileName  the tile name
     * @param snowValue the snow value
     *
     * @throws CommandException the command exception
     */
    @Command(command = "setsnow", description = "Sets the given Tile's snow value to the specified value.")
    @Argument(name = "tilename", baseType = String.class)
    @Argument(name = "snowvalue", baseType = Integer.class)
    public void setSnowCommandHandler(String tileName, int snowValue) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("A Tile's snow value can only be changed when game the is in Initialising state!");
        }
        if (tileReferenceDictionary.get(tileName) == null) {
            throw new CommandException("There is no Tile with the name: " + tileName + "!");
        }
        //todo: move this to snow setter.
        if (snowValue < 0) {
            throw new CommandException("Invalid snow value: " + snowValue + "!");
        }

        tileReferenceDictionary.get(tileName).getTile().setSnow(snowValue);
    }

    /**
     * Sets capacity command handler.
     *
     * @param tileName      the tile name
     * @param capacityValue the capacity value
     *
     * @throws CommandException the command exception
     */
    @Command(command = "setcapacity", description = "Sets the given Tile's capacity value to the specified value.")
    @Argument(name = "tilename", baseType = String.class)
    @Argument(name = "capacityvalue", baseType = Integer.class)
    public void setCapacityCommandHandler(String tileName, int capacityValue) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("A Tile's capacity value can only be changed when game the is in Initialising state!");
        }
        if (tileReferenceDictionary.get(tileName) == null) {
            throw new CommandException("There is no Tile with the name: " + tileName + "!");
        }
        if (capacityValue < 0) {
            throw new CommandException("Invalid capacity value: " + capacityValue + "!");
        }

        tileReferenceDictionary.get(tileName).getTile().setCapacity(capacityValue);
    }

    /**
     * Sets frozen command handler.
     *
     * @param tileName the tile name
     * @param thing    the thing
     *
     * @throws CommandException the command exception
     */
    @Command(command = "setfrozen", description = "Sets the given Tile's frozen thing to the specified value.")
    @Argument(name = "tilename", baseType = String.class)
    @Argument(name = "thingtype", baseType = Thing.class)
    public void setFrozenCommandHandler(String tileName, Thing thing) throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("A Tile's frozen thing can only be changed when game the is in Initialising state!");
        }
        if (tileReferenceDictionary.get(tileName) == null) {
            throw new CommandException("There is no Tile with the name: " + tileName + "!");
        }
        tileReferenceDictionary.get(tileName).getTile().setFrozenThing(thing);
    }

    /**
     * Start command handler.
     *
     * @throws CommandException the command exception
     */
    @Command(command = "start", description = "Starts the game.")
    public void startCommandHandler() throws CommandException {
        if (Game.Instance.getGameState() != GameState.Initialising) {
            throw new CommandException("The game can only be started when it is in Initialising state!");
        }
        Game.Instance.start();
    }

    /**
     * Move command handler.
     *
     * @param tilename the tilename
     *
     * @throws CommandException         the command exception
     * @throws NotEnoughEnergyException the not enough energy exception
     */
    @Command(command = "move", description = "The current creature moves to the given tile.")
    @Argument(name = "tilename", baseType = String.class)
    public void moveCommandHandler(String tilename) throws CommandException, NotEnoughEnergyException {
        if (Game.Instance.getGameState() != GameState.Playing) {
            throw new CommandException("The game can only be started when it is in Initialising state!");
        }
        Game.Instance.getCurrentCreature().move(getTileReferenceWithGivenName(tilename));
    }

    private TileReference getTileReferenceWithGivenName(String tilename) throws CommandException {
        TileReference tileReference = tileReferenceDictionary.get(tilename);

        if (tileReference == null) {
            throw new CommandException("No tile with given name!");
        }

        return tileReference;
    }

    /**
     * Use command handler.
     *
     * @param thingindex the thingindex
     *
     * @throws CommandException         the command exception
     * @throws NotEnoughEnergyException the not enough energy exception
     */
    @Command(command = "use", description = "The current Player uses the thing at the given index in the backpack.")
    @Argument(name = "thingindex", baseType = Integer.class)
    public void useCommandHandler(int thingindex) throws CommandException, NotEnoughEnergyException {
        Player player = getCurrentPlayer();
        Thing thing = getThingAtPlayersSpecifiedIndex(player, thingindex);

        player.useThing(thing);
    }

    private Player getCurrentPlayer() throws CommandException {
        if (Game.Instance.getCurrentCreature() instanceof Player) {
            return (Player) Game.Instance.getCurrentCreature();
        }

        throw new CommandException("The current creature is not a Player!");
    }

    private Thing getThingAtPlayersSpecifiedIndex(Player player, int thingindex) throws CommandException {
        Thing thing = player.getBackpack().get(thingindex);

        if (thing == null) {
            throw new CommandException("The player's Backpack does not have anything at the specified index!");
        }

        return thing;
    }

    /**
     * Pick up command handler.
     *
     * @param thingindex the thingindex
     *
     * @throws CommandException the command exception
     */
    @Command(command = "pickup", description = "The current Player picks up the Thing from the tile at the specified index.")
    @Argument(name = "thingindex", baseType = Integer.class)
    public void pickUpCommandHandler(int thingindex) throws CommandException {
        Player player = getCurrentPlayer();

        Thing thing = player.getStandingOn().getTile().getThing(thingindex);

        player.addThingToBackpack(thing);
    }

    /**
     * Throw command handler.
     *
     * @param thingindex the thingindex
     *
     * @throws CommandException the command exception
     */
    @Command(command = "throw", description = "The current Player throws the thing at the given index in the backpack.")
    @Argument(name = "thingindex", baseType = Integer.class)
    public void throwCommandHandler(int thingindex) throws CommandException {
        Player player = getCurrentPlayer();

        Thing thing = player.getBackpack().get(thingindex);

        player.getStandingOn().getTile().putThing(thing);
        player.removeThingFromBackpack(thing);
    }

    /**
     * Do ability command handler.
     *
     * @param tilename the tilename
     *
     * @throws CommandException the command exception
     */
    @Command(command = "doability", description = "The current Player does its special ability on the given tile.")
    @Argument(name = "tilename", baseType = String.class)
    public void doAbilityCommandHandler(String tilename) throws CommandException {
        try {
            getCurrentPlayer().doAbility(getTileReferenceWithGivenName(tilename));
        } catch (NotEnoughEnergyException e) {
            throw new CommandException("The current Player does not have enough energy!");
        }
    }

    /**
     * Storm command handler.
     *
     * @param stormValue the storm value
     *
     * @throws CommandException the command exception
     */
    @Command(command = "storm", description = "Starts a storm with the specified value.")
    @Argument(name = "stormvalue", baseType = Integer.class)
    public void stormCommandHandler(int stormValue) throws CommandException {
        if (stormValue < 0) {
            throw new CommandException("Invalid storm value: " + stormValue + "!");
        }

        Game.Instance.startStorm(stormValue);
    }

    /**
     * Next turn command handler.
     *
     * @throws CommandException the command exception
     */
    @Command(command = "nextturn", description = "Ends the turn of the current Creature.")
    public void nextTurnCommandHandler() throws CommandException {
        if (Game.Instance.getGameState() != GameState.Playing) {
            throw new CommandException("The game must be in Playing state!");
        }

        Game.Instance.nextTurn();
    }
}
