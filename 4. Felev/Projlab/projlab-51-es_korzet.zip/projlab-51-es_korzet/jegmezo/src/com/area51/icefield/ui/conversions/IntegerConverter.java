package com.area51.icefield.ui.conversions;

/**
 * A basic Integer converter {@link ITypeConverter}
 */
public final class IntegerConverter implements ITypeConverter {
    /**
     * {@inheritDoc}
     */
    @Override
    public Integer getInstanceOf(Class<?> baseType, String value) {
        return Integer.parseInt(value);
    }
}
