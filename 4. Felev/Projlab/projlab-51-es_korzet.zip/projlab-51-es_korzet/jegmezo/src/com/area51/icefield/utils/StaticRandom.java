package com.area51.icefield.utils;

import java.util.Random;

/**
 * Helper type that wraps {@link Random} into a static class
 */
public final class StaticRandom {
    private static final Random random = new Random();

    /**
     * Wrapper method for {@link Random#nextInt()}
     *
     * @return a random number
     *
     * @see Random#nextInt()
     */
    public static int nextInt() {
        return random.nextInt();
    }

    /**
     * Wrapper method for {@link Random#nextInt(int)}
     *
     * @param bound the upper bound
     *
     * @return a random number
     *
     * @see Random#nextInt(int)
     */
    public static int nextInt(int bound) {
        return random.nextInt(bound);
    }

    /**
     * Returns a new random Integer within the specified min-max values. Min is inclusive, max is exclusive.
     *
     * @param min the lower bound
     * @param max the upper bound
     *
     * @return a random number
     */
    public static int nextInt(int min, int max) {
        return random.nextInt(max - min) + min;
    }
}
