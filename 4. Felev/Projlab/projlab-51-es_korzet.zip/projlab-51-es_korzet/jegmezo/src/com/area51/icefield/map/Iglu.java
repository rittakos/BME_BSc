package com.area51.icefield.map;

import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * It is safe from attacks.
 *
 * @see Building
 */
@CommandArgumentType(value = "Iglu", baseType = Building.class)
public final class Iglu extends Building {
    /**
     * {@inheritDoc}
     */
    @Override
    public void update() { }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isSafeFromAttack() {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Iglu");
    }
}
