package com.area51.icefield.creatures;

import com.area51.icefield.Game;
import com.area51.icefield.map.TileReference;
import com.area51.icefield.things.BasicPickaxe;
import com.area51.icefield.things.BasicShovel;
import com.area51.icefield.things.Thing;
import com.area51.icefield.utils.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A jatekosokert felelolos osztaly aminek ose a Creature
 */
public abstract class Player extends Creature {
    private static final List<Player> players = new ArrayList<>();

    private final List<Thing> backpack = new ArrayList<>();
    private int bodyTemperature = getDefaultBodyTemperature();
    private boolean hasSwimmingSuit = false;

    /**
     * Instantiates a new Player.
     */
    protected Player() {
        players.add(this);

        backpack.add(new BasicPickaxe());
        backpack.add(new BasicShovel());
    }

    /**
     * Gets all known Player instances in an unmodifiable list.
     *
     * @return an unmodifiable list of Players.
     */
    public static List<Player> getPlayers() {
        return Collections.unmodifiableList(players);
    }

    /**
     * Gets the backpack.
     *
     * @return an unmodifiable list of the backpack
     */
    public final List<Thing> getBackpack() {
        return Collections.unmodifiableList(backpack);
    }

    /**
     * Beallitja, hogy van buvarruha a jatekosnal
     */
    public final void setHasSwimmingSuit() {
        hasSwimmingSuit = true;
    }

    /**
     * Add thing to backpack.
     *
     * @param thing the thing
     */
    public final void addThingToBackpack(Thing thing) {
        backpack.add(thing);
    }

    /**
     * Remove thing from backpack.
     *
     * @param thing the thing
     */
    public final void removeThingFromBackpack(Thing thing) {
        if (!backpack.contains(thing)) {
            throw new UnsupportedOperationException("The Players backpack does not contain the specified thing!");
        }

        backpack.remove(thing);
    }

    /**
     * Hasznal egy targyat, ha van elegendo energiaja
     *
     * @param thing the thing
     *
     * @throws NotEnoughEnergyException when the Player does not have enough energy.
     */
    public final void useThing(Thing thing) throws NotEnoughEnergyException {
        if (!backpack.contains(thing)) {
            throw new UnsupportedOperationException("The Players backpack does not contain the specified thing!");
        }

        ensureEnergyRequirements(thing.getRequiredEnergy());

        thing.use(this);
    }

    /**
     * Increases the temperature of the Player by 1.
     */
    public final void increaseTemperature() {
        if (bodyTemperature < 5) {
            bodyTemperature++;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected final int getDefaultEnergy() {
        return 4;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void kill() {
        super.kill();

        Game.Instance.lose();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected final void onVisit(TileReference tileReference) { }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void isInStorm() {
        if (--bodyTemperature == 0) {
            Game.Instance.lose();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Body temperature: " + bodyTemperature);
        Utils.writeTabs(tabs, "Has swimming suit: " + hasSwimmingSuit);
        Utils.writeTabs(tabs, "Backpack: [");
        for (Thing thing : backpack) {
            thing.dumpData(tabs + 1);
        }
        Utils.writeTabs(tabs, "]");
        super.dumpData(tabs);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void attacked() {
        kill();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void isInWater() {
        if (!hasSwimmingSuit || --bodyTemperature == 0) {
            kill();
        }
    }

    /**
     * Does the custom ability of the Player on the specified tile reference.
     *
     * @param tileReference the tile reference
     *
     * @throws NotEnoughEnergyException when the Player does not have enough energy.
     */
    public abstract void doAbility(TileReference tileReference) throws NotEnoughEnergyException;

    /**
     * Returns this Creature's default body temperature. Only called upon construction.
     *
     * @return the default body temperature
     */
    protected abstract int getDefaultBodyTemperature();
}
