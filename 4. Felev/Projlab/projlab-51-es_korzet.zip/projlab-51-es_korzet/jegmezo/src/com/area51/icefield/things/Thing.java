package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;

/**
 * The base Thing class hierarchy. Every Thing can be used for a given amount of energy.
 */
public abstract class Thing {
    /**
     * The Player uses this Thing.
     *
     * @param player the player
     */
    public abstract void use(Player player);

    /**
     * Gets required energy.
     *
     * @return the required energy
     */
    public abstract int getRequiredEnergy();

    /**
     * Dumps the Things description to stdout.
     *
     * @param tabs the tabs
     */
    public abstract void dumpData(int tabs);
}
