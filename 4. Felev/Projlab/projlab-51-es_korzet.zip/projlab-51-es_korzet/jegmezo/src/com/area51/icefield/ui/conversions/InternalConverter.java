package com.area51.icefield.ui.conversions;

import com.area51.icefield.Game;
import com.area51.icefield.creatures.Eskimo;
import com.area51.icefield.creatures.Scientist;
import com.area51.icefield.map.*;
import com.area51.icefield.things.*;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.AnnotationReader;

import java.util.List;
import java.util.stream.Collectors;

/**
 * The internal {@link ITypeConverter}. It can instantiate classes annotated with {@link CommandArgumentType}.
 */
public final class InternalConverter implements ITypeConverter {
    private static final List<ArgumentType> typesWithCommandArgumentTypeAnnotation = AnnotationReader.getClassesWithAnnotation(CommandArgumentType.class, Game.class.getPackage()).map(type -> new ArgumentType(type.getAnnotation(CommandArgumentType.class), type)).collect(Collectors.toUnmodifiableList());

    /**
     * {@inheritDoc}
     */
    @Override
    public Object getInstanceOf(Class<?> baseType, String value) throws TypeConverterException {
        ArgumentType argumentType = getArgumentType(baseType, value);

        if (argumentType.type.equals(BreakableShovel.class)) {
            return new BreakableShovel();
        } else if (argumentType.type.equals(Food.class)) {
            return new Food();
        } else if (argumentType.type.equals(Gun.class)) {
            return new Gun();
        } else if (argumentType.type.equals(GunPart.class)) {
            return new GunPart();
        } else if (argumentType.type.equals(PackedTent.class)) {
            return new PackedTent();
        } else if (argumentType.type.equals(Pickaxe.class)) {
            return new Pickaxe();
        } else if (argumentType.type.equals(Rope.class)) {
            return new Rope();
        } else if (argumentType.type.equals(Shovel.class)) {
            return new Shovel();
        } else if (argumentType.type.equals(SwimmingSuit.class)) {
            return new SwimmingSuit();
        } else if (argumentType.type.equals(Hole.class)) {
            return new Hole();
        } else if (argumentType.type.equals(StableIce.class)) {
            return new StableIce();
        } else if (argumentType.type.equals(UnstableIce.class)) {
            return new UnstableIce();
        } else if (argumentType.type.equals(Eskimo.class)) {
            return new Eskimo();
        } else if (argumentType.type.equals(Scientist.class)) {
            return new Scientist();
        } else if (argumentType.type.equals(Iglu.class)) {
            return new Iglu();
        } else if (argumentType.type.equals(Tent.class)) {
            return new Tent();
        }

        throw new TypeConverterException("Not expected value for type " + argumentType.annotation.baseType().toString());
    }

    private static ArgumentType getArgumentType(Class<?> baseType, String value) throws TypeConverterException {
        for (var type : typesWithCommandArgumentTypeAnnotation) {
            if (type.annotation.baseType().equals(baseType) && type.annotation.value().equals(value)) {
                return type;
            }
        }

        throw new TypeConverterException("Not expected value for type " + baseType.toString() + " with value of: " + value);
    }

    private static class ArgumentType {
        public final CommandArgumentType annotation;
        public final Class<?> type;

        public ArgumentType(CommandArgumentType annotation, Class<?> type) {
            this.annotation = annotation;
            this.type = type;
        }
    }
}
