package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A thing which can replenish the Player using it.
 */
@CommandArgumentType(value = "Food", baseType = Thing.class)
public final class Food extends Thing {
    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        player.increaseTemperature();
        player.removeThingFromBackpack(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getRequiredEnergy() {
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Food");
    }
}
