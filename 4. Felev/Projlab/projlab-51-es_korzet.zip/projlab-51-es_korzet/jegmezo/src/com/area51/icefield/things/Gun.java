package com.area51.icefield.things;

import com.area51.icefield.Game;
import com.area51.icefield.creatures.Player;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * The winning item: when used the game will be won, if state is according to needs.
 */
@CommandArgumentType(value = "Gun", baseType = Thing.class)
public final class Gun extends Thing {
    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        if (Player.getPlayers().stream().allMatch(x -> x.getStandingOn() == player.getStandingOn())) {
            player.removeThingFromBackpack(this);
            Game.Instance.win();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getRequiredEnergy() {
        return 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Gun");
    }
}