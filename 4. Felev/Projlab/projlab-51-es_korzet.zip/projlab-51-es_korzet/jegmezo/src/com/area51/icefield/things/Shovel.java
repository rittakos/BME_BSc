package com.area51.icefield.things;

import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A shovel that can shovel 2 layers of snow.
 */
@CommandArgumentType(value = "Shovel", baseType = Thing.class)
public class Shovel extends BasicShovel {
    /**
     * Instantiates a new Shovel.
     */
    public Shovel() {
        super(2);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Shovel");
    }
}
