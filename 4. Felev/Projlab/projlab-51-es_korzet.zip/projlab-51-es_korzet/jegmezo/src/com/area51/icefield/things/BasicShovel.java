package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A shovel that can shovel 1 layer of snow by default.
 */
@CommandArgumentType(value = "BasicShovel", baseType = Thing.class)
public class BasicShovel extends Thing {
    private final int layersOfSnow;

    /**
     * Instantiates a new Basic shovel.
     */
    public BasicShovel() {
        this(1);
    }

    /**
     * Instantiates a new Basic shovel with the given layersOfSnow digging capabilities.
     *
     * @param layersOfSnow the layers of snow
     */
    protected BasicShovel(int layersOfSnow) {
        this.layersOfSnow = layersOfSnow;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        player.getStandingOn().getTile().decreaseSnow(layersOfSnow);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final int getRequiredEnergy() {
        return 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "BasicShovel");
    }
}
