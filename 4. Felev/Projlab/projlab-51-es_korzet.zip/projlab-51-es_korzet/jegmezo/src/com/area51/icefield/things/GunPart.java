package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * When the player collects all GunPart instantiations any can be used to construct a {@link Gun}
 */
@CommandArgumentType(value = "GunPart", baseType = Thing.class)
public final class GunPart extends Thing {
    private final static List<Thing> gunParts = new ArrayList<>();

    /**
     * Instantiates a new gun part.
     */
    public GunPart() {
        gunParts.add(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        if (!player.getBackpack().containsAll(gunParts)) {
            return;
        }

        for (var thing : player.getBackpack()) {
            player.removeThingFromBackpack(thing);
        }

        player.addThingToBackpack(new Gun());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getRequiredEnergy() {
        return 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "GunPart");
    }
}
