package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * When used, the {@link Player#setHasSwimmingSuit()} will be called.
 */
@CommandArgumentType(value = "SwimmingSuit", baseType = Thing.class)
public final class SwimmingSuit extends Thing {
    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        player.setHasSwimmingSuit();
        player.removeThingFromBackpack(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getRequiredEnergy() {
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "SwimmingSuit");
    }
}
