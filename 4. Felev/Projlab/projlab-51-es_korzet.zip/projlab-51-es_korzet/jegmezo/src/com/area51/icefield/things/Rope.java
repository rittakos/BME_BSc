package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * Can be used to pull out a {@link Player} from a {@link com.area51.icefield.map.Hole}.
 */
@CommandArgumentType(value = "Rope", baseType = Thing.class)
public final class Rope extends Thing {
    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        for (var tile : player.getStandingOn().getNeighbours()) {
            for (var creature : tile.getTile().getCreatures()) {
                if (Player.getPlayers().contains(creature)) {
                    creature.getStandingOn().getTile().removeCreature(creature);
                    creature.setStandingOn(player.getStandingOn());
                    creature.getStandingOn().getTile().addCreature(creature);
                }
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getRequiredEnergy() {
        return 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Rope");
    }
}
