package com.area51.icefield.ui;

/**
 * An exception thrown when an internal error occurs.
 */
public class InternalException extends Exception {
    /**
     * Instantiates a new CommandException.
     *
     * @param message the message
     */
    public InternalException(String message) {
        super(message);
    }

    /**
     * Instantiates a new CommandException.
     *
     * @param message the message
     * @param cause   the cause
     */
    public InternalException(String message, Throwable cause) {
        super(message, cause);
    }
}
