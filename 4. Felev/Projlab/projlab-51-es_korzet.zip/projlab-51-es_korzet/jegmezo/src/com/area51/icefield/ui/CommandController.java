package com.area51.icefield.ui;

import com.area51.icefield.ui.annotations.Argument;
import com.area51.icefield.ui.annotations.Command;
import com.area51.icefield.ui.conversions.TypeConverter;
import com.area51.icefield.ui.conversions.TypeConverterException;
import com.area51.icefield.utils.AnnotationReader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * The main class of the Command processing system.
 */
public final class CommandController {
    private static final GameCommandController game = new GameCommandController();
    private static final List<CommandDescriptor> commands = AnnotationReader.getMethodsWithAnnotation(Command.class, GameCommandController.class).map(method -> new CommandDescriptor(method.getAnnotation(Command.class), method)).collect(Collectors.toList());

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        if (args.length > 1) {
            System.out.println("Usage: test.jar <scriptfile>");
        } else if (args.length == 1) {
            try {
                runScript(args[0]);
            } catch (CommandException e) {
                System.out.println(e.getMessage());
            } catch (InternalException e) {
                System.err.println(e.getMessage());
            } catch (Throwable throwable) {
                throwable.printStackTrace();
            }
        } else {
            startCli();
        }
    }

    /**
     * Starts reading commands from stdin.
     */
    private static void startCli() {
        var in = new Scanner(System.in);
        var running = true;
        var line = "";

        while (running) {
            System.out.print("> ");

            try {
                line = in.nextLine();
            } catch (NoSuchElementException e) {
                break;
            }

            switch (line) {
                case "exit": {
                    running = false;
                    break;
                }
                case "---": {
                    game.dumpCommandHandler();
                    break;
                }
                case "help": {
                    writeHelpInfo();
                    break;
                }
                default: {
                    try {
                        execute(line);
                    } catch (CommandException e) {
                        System.out.println(e.getMessage());
                    } catch (InternalException e) {
                        System.err.println(e.getMessage());
                    } catch (Throwable throwable) {
                        throwable.printStackTrace();
                    }
                    break;
                }
            }
        }
    }

    /**
     * Writes help-info to stdout
     */
    private static void writeHelpInfo() {
        System.out.println("Available commands:");

        for (var command : commands) {
            System.out.print("    " + command.annotation.command() + " ");

            for (var arg : command.method.getAnnotationsByType(Argument.class)) {
                System.out.print("<" + arg.name() + "> ");
            }

            System.out.println("- " + command.annotation.description());
        }

        System.out.println("    help - Show this help");
        System.out.println("    exit - exit");
    }

    /**
     * Reads and executes the given script.
     *
     * @param scriptPath the path to the script.
     *
     * @throws Throwable any error may occur..
     */
    private static void runScript(String scriptPath) throws Throwable {
        try {
            var reader = new BufferedReader(new FileReader(scriptPath));

            var command = reader.readLine();

            while (command != null) {
                execute(command);

                command = reader.readLine();
            }

            execute("dump");
        } catch (FileNotFoundException e) {
            throw new InternalException("Script file can not be found!");
        } catch (IOException e) {
            throw new InternalException("Error while reading script file!", e);
        }
    }

    /**
     * Executes the given command.
     *
     * @param commandline the line of command
     *
     * @throws Throwable any error may occur..
     */
    private static void execute(String commandline) throws Throwable {
        if (commandline.isBlank()) {
            return;
        }

        var commandSplit = commandline.split(" ");
        var command = getCommandWithName(commandSplit[0]);

        try {
            var arguments = parseCommandArguments(command, commandSplit);
            command.method.invoke(game, arguments.toArray());
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            System.exit(1); // F.. we can not continue from here, bail out!
        } catch (InvocationTargetException e) {
            throw e.getCause(); // Command handler threw the exception, better throw the original upwards.
        }
    }

    /**
     * Parses the given arguments according to the commands argument types.
     *
     * @param commandDescriptor the deduced commandDescriptor to be executed
     * @param cmdspl            the command split by ' ' characters.
     *
     * @return a list of instantiated values of the arguments.
     *
     * @throws CommandException when there is either wrong amount of arguments, or {@link TypeConverter} threw an error.
     */
    private static List<Object> parseCommandArguments(CommandDescriptor commandDescriptor, String[] cmdspl) throws CommandException {
        var toReturn = new ArrayList<>();
        var arguments = commandDescriptor.method.getAnnotationsByType(Argument.class);

        if (cmdspl.length - 1 != arguments.length) {
            throw new CommandException(String.format("Command has invalid argument count! (expected %d got %d)", arguments.length, cmdspl.length - 1));
        }

        int i = 0;
        try {
            for (; i < arguments.length; i++) {
                toReturn.add(TypeConverter.convert(arguments[i].baseType(), cmdspl[i + 1]));
            }
        } catch (TypeConverterException e) {
            throw new CommandArgumentException(arguments[i], cmdspl[i + 1], e);
        }

        return toReturn;
    }

    /**
     * Searches for the given command.
     *
     * @param commandName the name of the command
     *
     * @return The C
     *
     * @throws CommandException if the given command can not be found.
     */
    private static CommandDescriptor getCommandWithName(String commandName) throws CommandException {
        return commands.stream()
                .filter(command -> commandName.equals(command.annotation.command()))
                .findFirst()
                .orElseThrow(() -> new CommandNotFoundException(commandName));
    }

    private static final class CommandDescriptor {
        public final Command annotation;
        public final Method method;

        public CommandDescriptor(Command annotation, Method method) {
            this.annotation = annotation;
            this.method = method;
        }
    }
}
