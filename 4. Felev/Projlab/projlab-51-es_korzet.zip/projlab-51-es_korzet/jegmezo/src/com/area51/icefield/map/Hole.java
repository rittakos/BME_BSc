package com.area51.icefield.map;

import com.area51.icefield.creatures.Creature;
import com.area51.icefield.things.Thing;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A Hole has 0 capacity, and every when a Creature steps on it {@link Creature#isInWater()} will be called on it.
 */
@CommandArgumentType(value = "Hole", baseType = Tile.class)
public final class Hole extends Tile {
    /**
     * Instantiates a new Hole.
     */
    public Hole() {
        super();
    }

    /**
     * Instantiates a new Hole with the given tile reference.
     *
     * @param tileReference the tile reference
     */
    public Hole(TileReference tileReference) {
        super(tileReference);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setBuilding(Building building) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Hole can not have a building!");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addCreature(Creature creature) {
        super.addCreature(creature);

        creature.isInWater();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void update() {
        super.update();

        for (Creature creature : getCreatures()) {
            creature.isInWater();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Type: Hole");

        super.dumpData(tabs);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setFrozenThing(Thing frozenThing) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Hole can not have a frozen thing!");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getCapacity() {
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setCapacity(int capacity) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Hole can not have a capacity!");
    }
}
