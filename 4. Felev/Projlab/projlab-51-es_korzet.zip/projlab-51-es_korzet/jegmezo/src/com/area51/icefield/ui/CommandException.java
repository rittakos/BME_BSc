package com.area51.icefield.ui;

/**
 * An exception thrown when an error occurs during a Command
 */
public class CommandException extends Exception {
    /**
     * Instantiates a new CommandException.
     *
     * @param message the message
     */
    public CommandException(String message) {
        super(message);
    }

    /**
     * Instantiates a new CommandException.
     *
     * @param message the message
     * @param cause   the causing Throwable
     */
    public CommandException(String message, Throwable cause) {
        super(message, cause);
    }
}

