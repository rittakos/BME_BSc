package com.area51.icefield.creatures;

import com.area51.icefield.map.TileReference;
import com.area51.icefield.utils.Utils;

/**
 * A jatekosok es a jegesmedve kozos abstract ose.
 * Every creature can move around, has a living state, and energy for different tasks.
 */
public abstract class Creature {
    private TileReference standingOn;
    private boolean isAlive = true;
    private int energy = getDefaultEnergy();

    /**
     * Refreshes the energy of the creature to the default value.
     */
    public final void refreshEnergy() {
        this.energy = getDefaultEnergy();
    }

    /**
     * Returns this Creatures default energy. {@link Creature#refreshEnergy()} calls this method.
     *
     * @return the default energy
     */
    protected abstract int getDefaultEnergy();

    /**
     * Moves the Creature to the specified tile reference, costing 1 energy at the same time.
     *
     * @param tileReference the tile reference
     *
     * @throws NotEnoughEnergyException when the creature does not have enough energy.
     */
    public final void move(TileReference tileReference) throws NotEnoughEnergyException {
        if (!getStandingOn().getNeighbours().contains(tileReference)) {
            throw new UnsupportedOperationException("The given TileReference is not a neighbour!");
        }

        ensureEnergyRequirements(1);

        standingOn.getTile().removeCreature(this);
        setStandingOn(tileReference);
        standingOn.getTile().addCreature(this);
    }

    /**
     * Gets the tile reference this Creature is standing on.
     *
     * @return the tile reference
     */
    public final TileReference getStandingOn() {
        return standingOn;
    }

    /**
     * Sets the tile reference this Creature is standing on.
     *
     * @param tileReference the tile reference
     */
    public final void setStandingOn(TileReference tileReference) {
        this.standingOn = tileReference;

        onVisit(standingOn);
    }

    /**
     * Ensures energy requirements, and if met, decreases the energy value of the Creature.
     *
     * @param neededEnergy the needed energy
     *
     * @throws NotEnoughEnergyException when the creature does not have enough energy.
     */
    protected final void ensureEnergyRequirements(int neededEnergy) throws NotEnoughEnergyException {
        if (energy < neededEnergy) {
            throw new NotEnoughEnergyException(energy, neededEnergy);
        }

        energy -= neededEnergy;
    }

    /**
     * This method gets called every time {@link Creature#setStandingOn(TileReference)} method is called.
     *
     * @param tileReference the tile reference
     */
    protected abstract void onVisit(TileReference tileReference);

    /**
     * Kills the creature.
     */
    protected void kill() {
        isAlive = false;
    }

    /**
     * Dumps the Creature's description to stdout.
     *
     * @param tabs the tabs
     */
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Is alive: " + isAlive);
        Utils.writeTabs(tabs, "Energy: " + energy);
    }

    /**
     * The creature gets into a storm.
     */
    public abstract void isInStorm();

    /**
     * This method gets called when the Creature is attacked.
     */
    public abstract void attacked();

    /**
     * This method gets called when the Creature is in water.
     */
    public abstract void isInWater();
}
