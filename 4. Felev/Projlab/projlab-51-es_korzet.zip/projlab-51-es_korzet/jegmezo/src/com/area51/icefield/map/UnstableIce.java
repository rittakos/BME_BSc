package com.area51.icefield.map;

import com.area51.icefield.creatures.Creature;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A Stable ice has a set capacity, and can contain a frozen thing.
 */
@CommandArgumentType(value = "Unstable", baseType = Tile.class)
public final class UnstableIce extends Tile {
    private int capacity = 0;

    /**
     * {@inheritDoc}
     */
    @Override
    public void setBuilding(Building building) {
        super.setBuilding(building);

        checkCapacity();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addCreature(Creature creature) {
        super.addCreature(creature);

        checkCapacity();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Type: Unstable");
        Utils.writeTabs(tabs, "Capacity: " + capacity);

        super.dumpData(tabs);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getCapacity() {
        return capacity;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    private void checkCapacity() {
        if (getCreatures().size() + (getBuilding() != null ? 1 : 0) > getCapacity()) {
            Hole hole = new Hole();

            for (Creature standingOn : getCreatures()) {
                hole.addCreature(standingOn);
            }
            getTileReference().setTile(hole);
        }
    }
}
