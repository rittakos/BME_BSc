package com.area51.icefield.map;

import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * It is not safe from attacks. It will be destroyed after 3 updates.
 *
 * @see Building
 */
@CommandArgumentType(value = "Tent", baseType = Building.class)
public final class Tent extends Building {
    private int age = 0;

    /**
     * {@inheritDoc}
     */
    @Override
    public void update() {
        if (++age == 3) {
            getTileReference().getTile().setBuilding(null);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isSafeFromAttack() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Tent");
        Utils.writeTabs(tabs + 1, "age: " + age);
    }
}
