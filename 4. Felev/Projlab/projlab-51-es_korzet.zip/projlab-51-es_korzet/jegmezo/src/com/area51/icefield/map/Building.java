package com.area51.icefield.map;

/**
 * The base class for all Buildings. A building can be placed on a {@link TileReference}, and it saves from storm,
 * and may or may not save from an attack.
 */
public abstract class Building {
    private TileReference tileReference = null;

    /**
     * Gets the tile reference.
     *
     * @return the tile reference.
     */
    public final TileReference getTileReference() {
        return tileReference;
    }

    /**
     * Sets the tile reference.
     *
     * @param tileReference the tileReference
     */
    public final void setTileReference(TileReference tileReference) {
        this.tileReference = tileReference;
    }

    /**
     * Updates the Building.
     */
    public abstract void update();

    /**
     * Returns whether it is safe from an attack or not.
     *
     * @return whether it is safe or not.
     */
    public abstract boolean isSafeFromAttack();

    /**
     * Dumps the Buildings description to stdout.
     *
     * @param tabs the tabs
     */
    public abstract void dumpData(int tabs);
}
