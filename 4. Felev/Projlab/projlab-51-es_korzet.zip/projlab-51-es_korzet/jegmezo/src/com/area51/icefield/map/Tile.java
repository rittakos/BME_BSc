package com.area51.icefield.map;

import com.area51.icefield.creatures.Creature;
import com.area51.icefield.things.Thing;
import com.area51.icefield.utils.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A tablakert felelos abstract osztaly
 */
public abstract class Tile {
    private final List<Thing> things = new ArrayList<>();
    private final List<Creature> creatures = new ArrayList<>();
    private final TileReference tileReference;
    private Thing frozenThing = null;
    private Building building = null;
    private int snow = 0;

    /**
     * Instantiates a new Tile.
     */
    public Tile() {
        this(new TileReference());
    }

    /**
     * Instantiates a new Tile with the specified tile reference
     *
     * @param tileReference the tile reference
     */
    protected Tile(TileReference tileReference) {
        this.tileReference = tileReference;
        tileReference.setTile(this);
    }

    /**
     * Gets tile reference.
     *
     * @return the tile reference
     */
    public final TileReference getTileReference() { return tileReference; }

    /**
     * Adott indexu targyat adja vissza azok kozul amik a tablan vannak
     *
     * @param index the index
     *
     * @return the thing
     */
    public final Thing getThing(int index) {
        if (things.size() == 0) {
            return null;
        }

        Thing thing = things.get(index);
        things.remove(thing);

        return thing;
    }

    /**
     * Lerak egy targyata tablara
     *
     * @param thing the thing
     */
    public final void putThing(Thing thing) {
        things.add(thing);
    }

    /**
     * Megadaja a ho mennyiseget a tablan
     *
     * @return the snow
     */
    public final int getSnow() {
        return snow;
    }

    /**
     * Beallitja a ho mennyiseget a tablan
     *
     * @param snow the snow
     */
    public final void setSnow(int snow) {
        this.snow = snow;
    }

    /**
     * Megadja az epuletet a tablan
     *
     * @return the building
     */
    public final Building getBuilding() { return building; }

    /**
     * Beallitja az epuletet a tablan
     *
     * @param building the building
     */
    public void setBuilding(Building building) throws UnsupportedOperationException {
        this.building = building;

        if (building != null) {
            building.setTileReference(tileReference);
        }
    }

    /**
     * Megadja a creature-okat tablan
     *
     * @return an unmodifiable list of the creatures
     */
    public final List<Creature> getCreatures() {
        return Collections.unmodifiableList(creatures);
    }

    /**
     * Ervenyesiti a vihart a tablan
     *
     * @param stormValue the storm value
     */
    public final void doStorm(int stormValue) {
        snow += stormValue;

        if (building == null) {
            for (Creature creature : creatures) {
                creature.isInStorm();
            }
        }
    }

    /**
     * Megtoli a jatekosokat, ha nincsen biztonsagos epulet
     */
    public final void attack() {
        if (building == null || !building.isSafeFromAttack()) {
            for (Creature creature : creatures) {
                creature.attacked();
            }
        }
    }

    /**
     * Csokkenti a ho mennyiseget adott ertekkel
     *
     * @param by the by
     */
    public final void decreaseSnow(int by) {
        snow -= by;
    }

    /**
     * Kiassa a targyat a jegbol
     */
    public final void digUp() {
        things.add(frozenThing);
        frozenThing = null;
    }

    /**
     * Hozzaadja a megadott creature-t
     *
     * @param creature the creature
     */
    public void addCreature(Creature creature) {
        creatures.add(creature);
    }

    /**
     * Eltavolitja a megadott creature-t
     *
     * @param creature the creature
     */
    public void removeCreature(Creature creature) {
        creatures.remove(creature);
    }

    /**
     * Updates the Tile
     */
    public void update() {
        if (building != null) {
            building.update();
        }
    }

    /**
     * Kiirja az adatokat
     *
     * @param tabs the tabs
     */
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Things: [");
        for (Thing thing : things) {
            thing.dumpData(tabs + 1);
        }
        Utils.writeTabs(tabs, "]");

        if (building != null) {
            Utils.writeTabs(tabs, "Building:");
            building.dumpData(tabs + 1);
        } else {
            Utils.writeTabs(tabs, "Building: none");
        }

        if (frozenThing != null) {
            Utils.writeTabs(tabs, "Frozen thing:");
            frozenThing.dumpData(tabs + 1);
        } else {
            Utils.writeTabs(tabs, "Frozen thing: none");
        }

        Utils.writeTabs(tabs, "Snow value: " + snow);
    }

    /**
     * Sets frozen thing.
     *
     * @param frozenThing the frozen thing
     */
    public void setFrozenThing(Thing frozenThing) throws UnsupportedOperationException {
        this.frozenThing = frozenThing;
    }

    /**
     * Megadja a tabla kapacitasat
     *
     * @return the capacity
     */
    public abstract int getCapacity();

    /**
     * Beallitja a tabla kapacitasat
     *
     * @param capacity the capacity
     */
    public abstract void setCapacity(int capacity) throws UnsupportedOperationException;
}
