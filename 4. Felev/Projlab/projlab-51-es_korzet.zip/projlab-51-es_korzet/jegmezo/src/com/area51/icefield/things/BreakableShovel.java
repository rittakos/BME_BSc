package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A Shovel which can only be used 3 times, after which it will break.
 */
@CommandArgumentType(value = "BreakableShovel", baseType = Thing.class)
public final class BreakableShovel extends Shovel {
    private int useTimes = 0;

    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        super.use(player);

        if (++useTimes == 3) {
            player.removeThingFromBackpack(this);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "BreakableShovel");
        Utils.writeTabs(tabs + 1, "Use times: " + useTimes);
    }
}
