package com.area51.icefield.things;

import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A Pickaxe that can be used for 1 energy.
 */
@CommandArgumentType(value = "Pickaxe", baseType = Thing.class)
public final class Pickaxe extends BasicPickaxe {
    /**
     * Instantiates a new Pickaxe.
     */
    public Pickaxe() {
        super(1);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Pickaxe");
    }
}
