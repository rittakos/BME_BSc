package com.area51.icefield.utils;

import java.io.File;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 * Contains helper methods for Annotation processing.
 */
public final class AnnotationReader {
    private static List<Class<?>> getClasses(String packageName) throws ClassNotFoundException, IOException {
        var classLoader = Thread.currentThread().getContextClassLoader();
        assert classLoader != null;
        var path = packageName.replace('.', '/');
        var resources = classLoader.getResources(path);
        var dirs = new ArrayList<File>();
        while (resources.hasMoreElements()) {
            URL resource = resources.nextElement();
            dirs.add(new File(resource.getFile()));
        }
        List<Class<?>> classes = new ArrayList<>();
        for (var directory : dirs) {
            classes.addAll(findClasses(directory, packageName));
        }
        return classes;
    }

    private static List<Class<?>> findClasses(File directory, String packageName) throws ClassNotFoundException {
        List<Class<?>> classes = new ArrayList<>();
        if (!directory.exists()) {
            return classes;
        }
        var files = directory.listFiles();
        if (files == null) {
            return classes;
        }
        for (var file : files) {
            if (file.isDirectory()) {
                assert !file.getName().contains(".");
                classes.addAll(findClasses(file, packageName + "." + file.getName()));
            } else if (file.getName().endsWith(".class")) {
                classes.add(Class.forName(packageName + '.' + file.getName().substring(0, file.getName().length() - 6)));
            }
        }
        return classes;
    }

    /**
     * Returns a stream for all classes with the given annotation inside the specified package
     *
     * @param <T>        the of the annotation
     * @param annotation the annotation
     * @param p          the package
     *
     * @return the stream containing the Classes
     */
    public static <T extends Annotation> Stream<Class<?>> getClassesWithAnnotation(Class<T> annotation, Package p) {
        try {
            return getClasses(p.getName())
                    .stream()
                    .filter(c -> c.isAnnotationPresent(annotation));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Stream.empty();
    }

    /**
     * Returns a stream for all methods with the given annotation inside the specified type.
     *
     * @param <T>        the of the annotation
     * @param annotation the annotation
     * @param type       the class to search for inside.
     *
     * @return the stream containing the Methods
     */
    public static <T extends Annotation> Stream<Method> getMethodsWithAnnotation(Class<T> annotation, Class<?> type) {
        return Arrays.stream(type.getMethods()).filter(m -> m.isAnnotationPresent(annotation));
    }
}
