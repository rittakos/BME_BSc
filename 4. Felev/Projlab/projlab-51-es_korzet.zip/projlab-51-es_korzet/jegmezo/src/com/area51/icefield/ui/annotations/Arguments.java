package com.area51.icefield.ui.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Repeatable {@link Argument}
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface Arguments {
    /**
     * The {@link Argument}s
     *
     * @return The {@link Argument}s
     */
    Argument[] value();
}