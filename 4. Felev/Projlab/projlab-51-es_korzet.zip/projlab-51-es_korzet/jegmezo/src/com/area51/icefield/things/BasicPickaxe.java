package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A pickaxe that can be used for 2 energy by default.
 */
@CommandArgumentType(value = "BasicPickaxe", baseType = Thing.class)
public class BasicPickaxe extends Thing {
    private final int requiredEnergy;

    /**
     * Instantiates a new Basic pickaxe.
     */
    public BasicPickaxe() {
        this(2);
    }

    /**
     * Instantiates a new Basic pickaxe with the given energy required.
     *
     * @param requiredEnergy the required energy
     */
    protected BasicPickaxe(int requiredEnergy) {
        this.requiredEnergy = requiredEnergy;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        player.getStandingOn().getTile().digUp();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final int getRequiredEnergy() {
        return requiredEnergy;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "BasicPickaxe");
    }
}
