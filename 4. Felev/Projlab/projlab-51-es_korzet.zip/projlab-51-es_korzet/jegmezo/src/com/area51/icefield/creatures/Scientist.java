package com.area51.icefield.creatures;

import com.area51.icefield.map.TileReference;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * A Scientist has 4 body temperature by default, and can build check how many Creatures can be on a given tile.
 */
@CommandArgumentType(value = "Scientist", baseType = Player.class)
public final class Scientist extends Player {
    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Type: Scientist");

        super.dumpData(tabs);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doAbility(TileReference tileReference) throws NotEnoughEnergyException {
        ensureEnergyRequirements(1);
        // TODO: right now we don't do anything with this ..
        tileReference.getTile().getCapacity();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getDefaultBodyTemperature() {
        return 4;
    }
}
