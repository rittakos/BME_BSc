package com.area51.icefield.ui.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Classes annotated with this annotation take part in the Conversion system. They can be {@link Argument} types.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface CommandArgumentType {
    /**
     * The base-type of the Argument type.
     *
     * @return the base-type
     */
    Class<?> baseType();

    /**
     * The string representing this sub-type of the base-type.
     *
     * @return the string representing this sub-type
     */
    String value();
}
