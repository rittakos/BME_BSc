package com.area51.icefield.ui.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Methods annotated with this annotation represent Commands. These methods may be invoked dynamically through the {@link com.area51.icefield.ui.CommandController} system.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface Command {
    /**
     * @return the string representing the command.
     */
    String command();

    /**
     * @return the description of the command.
     */
    String description();
}
