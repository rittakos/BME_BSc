package com.area51.icefield.things;

import com.area51.icefield.creatures.Player;
import com.area51.icefield.map.Tent;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * Can be used to put down a {@link Tent} on the {@link com.area51.icefield.map.TileReference} the {@link Player} stands on.
 */
@CommandArgumentType(value = "PackedTent", baseType = Thing.class)
public final class PackedTent extends Thing {
    /**
     * {@inheritDoc}
     */
    @Override
    public void use(Player player) {
        player.getStandingOn().getTile().setBuilding(new Tent());
        player.removeThingFromBackpack(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getRequiredEnergy() {
        return 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "PackedTent");
    }
}
