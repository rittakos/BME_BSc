package com.area51.icefield;

import com.area51.icefield.creatures.Creature;
import com.area51.icefield.map.TileReference;

import java.util.ArrayList;
import java.util.List;

/**
 * The main class for the business logic. It is a singleton.
 */
public final class Game {
    /**
     * The only instance of this singleton class.
     */
    public static final Game Instance = new Game();

    private final List<TileReference> tileReferences = new ArrayList<>();
    private final List<Creature> creatures = new ArrayList<>();

    private GameState gameState = GameState.Initialising;
    private int creatureIndex = 0;

    private Game() { }

    /**
     * Sets the gameState to {@link GameState#Won}
     */
    public void win() {
        gameState = GameState.Won;
    }

    /**
     * Sets the gameState to {@link GameState#Lost}
     */
    public void lose() {
        gameState = GameState.Lost;
    }

    /**
     * Adds the givent tileReference to the game.
     *
     * @param tileReference the tile reference
     */
    public void addTileReference(TileReference tileReference) {
        tileReferences.add(tileReference);
    }

    /**
     * Adds the given creature to the game.
     *
     * @param creature the creature
     */
    public void addCreature(Creature creature) {
        creatures.add(creature);
    }

    /**
     * Sets the gameState to {@link GameState#Playing}
     */
    public void start() {
        gameState = GameState.Playing;
    }

    /**
     * Updates all objects, and sets currentCreature to the next one.
     */
    public void nextTurn() {
        creatureIndex = (creatureIndex + 1) % creatures.size();

        update();
    }

    /**
     * Updates all objects.
     */
    public void update() {
        for (TileReference tileReference : tileReferences) {
            tileReference.getTile().update();
        }

        getCurrentCreature().refreshEnergy();
    }

    /**
     * Gets current creature.
     *
     * @return the current creature
     */
    public Creature getCurrentCreature() {
        return creatures.get(creatureIndex);
    }

    /**
     * Starts a new storm with the given value.
     *
     * @param stormValue the storm value
     */
    public void startStorm(int stormValue) {
        for (TileReference tileReference : tileReferences) {
            tileReference.getTile().doStorm(stormValue);
        }
    }

    /**
     * Gets game state.
     *
     * @return the game state
     */
    public GameState getGameState() { return gameState; }
}
