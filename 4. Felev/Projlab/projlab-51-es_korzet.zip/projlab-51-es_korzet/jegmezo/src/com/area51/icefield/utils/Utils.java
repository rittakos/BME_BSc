package com.area51.icefield.utils;

/**
 * Miscellaneous utility function container.
 */
public class Utils {
    /**
     * Writes the specified string to stdout prepended with the given number of '\t' characters.
     *
     * @param tabs   the number of tabs
     * @param string the string
     */
    public static void writeTabs(int tabs, String string) {
        for (int i = 0; i < tabs; i++) {
            System.out.print('\t');
        }

        System.out.println(string);
    }
}
