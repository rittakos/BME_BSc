package com.area51.icefield.ui.conversions;

import com.area51.icefield.ui.InternalException;

/**
 * An exception thrown when TypeConversion error occurs.
 */
public class TypeConverterException extends InternalException {
    /**
     * Constructs a new TypeConverterException
     *
     * @param message the message
     */
    public TypeConverterException(String message) {
        super(message);
    }
}
