package com.area51.icefield.ui;

/**
 * An exception thrown when the given command does not exist.
 */
public class CommandNotFoundException extends CommandException {
    /**
     * Instantiates a new CommandException.
     *
     * @param commandName the name of the command
     */
    public CommandNotFoundException(String commandName) {
        super("The specified command does not exist: " + commandName);
    }
}
