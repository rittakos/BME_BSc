package com.area51.icefield.creatures;

/**
 * An exception thrown when a {@link Creature} does not have enough energy for a task.
 */
public final class NotEnoughEnergyException extends Exception {
    /**
     * Instantiates a new Not enough energy exception.
     *
     * @param energy       the current energy
     * @param neededEnergy the neededEnergy
     */
    public NotEnoughEnergyException(int energy, int neededEnergy) {
        super("Not enough energy for task! Creature has: " + energy + " but needs: " + neededEnergy);
    }
}
