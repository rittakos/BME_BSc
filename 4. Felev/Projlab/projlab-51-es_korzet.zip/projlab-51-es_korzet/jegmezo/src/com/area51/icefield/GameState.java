package com.area51.icefield;

/**
 * The enum Game state.
 */
public enum GameState {
    /**
     * Initialising game state.
     */
    Initialising,
    /**
     * Playing game state.
     */
    Playing,
    /**
     * Won game state.
     */
    Won,
    /**
     * Lost game state.
     */
    Lost
}
