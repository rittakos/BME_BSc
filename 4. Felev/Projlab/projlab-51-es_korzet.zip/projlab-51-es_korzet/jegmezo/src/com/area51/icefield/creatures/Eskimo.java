package com.area51.icefield.creatures;

import com.area51.icefield.map.Iglu;
import com.area51.icefield.map.TileReference;
import com.area51.icefield.ui.annotations.CommandArgumentType;
import com.area51.icefield.utils.Utils;

/**
 * An Eskimo has 5 body temperature by default, and can build an Iglu.
 */
@CommandArgumentType(value = "Eskimo", baseType = Player.class)
public final class Eskimo extends Player {
    /**
     * {@inheritDoc}
     */
    @Override
    public void dumpData(int tabs) {
        Utils.writeTabs(tabs, "Type: Eskimo");

        super.dumpData(tabs);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doAbility(TileReference tileReference) throws NotEnoughEnergyException {
        ensureEnergyRequirements(1);

        tileReference.getTile().setBuilding(new Iglu());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected int getDefaultBodyTemperature() {
        return 5;
    }
}
