package com.area51.icefield.ui.conversions;

/**
 * Static class containing {@link ITypeConverter}s, and choosing between them for conversion.
 */
public final class TypeConverter {
    /**
     * Returns an Instance of the baseType with the given value.
     *
     * @param baseType the baseType
     * @param value    the value
     *
     * @return the a new instance of baseType
     *
     * @throws TypeConverterException when type conversion error occurs.
     */
    public static Object convert(Class<?> baseType, String value) throws TypeConverterException {
        return findConverter(baseType).getInstanceOf(baseType, value);
    }

    private static ITypeConverter findConverter(Class<?> expected) {
        if (String.class.equals(expected)) {
            return new StringConverter();
        } else if (Integer.class.equals(expected)) {
            return new IntegerConverter();
        }
        return new InternalConverter();
    }
}
