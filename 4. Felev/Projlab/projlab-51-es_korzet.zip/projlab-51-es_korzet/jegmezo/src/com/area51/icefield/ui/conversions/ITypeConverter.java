package com.area51.icefield.ui.conversions;

/**
 * Represents a class that can convert a value to a Types value.
 */
public interface ITypeConverter {
    /**
     * Gets a new instance of the given baseType with the specified value.
     *
     * @param baseType the baseType.
     * @param value    the value of the baseType
     *
     * @return a new instance of BaseType
     *
     * @throws TypeConverterException when conversion encountered an error.
     */
    Object getInstanceOf(Class<?> baseType, String value) throws TypeConverterException;
}
