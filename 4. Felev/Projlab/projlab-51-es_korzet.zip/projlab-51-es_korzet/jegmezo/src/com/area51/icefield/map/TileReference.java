package com.area51.icefield.map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The type Tile reference.
 */
public final class TileReference {
    private final List<TileReference> neighbours = new ArrayList<>();
    private Tile tile;

    /**
     * Adds a tileReference as a neighbour to this one.
     *
     * @param tileReference the tile reference
     */
    public void addNeighbour(TileReference tileReference) {
        neighbours.add(tileReference);
    }

    /**
     * Gets neighbours.
     *
     * @return the neighbours
     */
    public List<TileReference> getNeighbours() {
        return Collections.unmodifiableList(neighbours);
    }

    /**
     * Gets tile this tileReference represents.
     *
     * @return the tile
     */
    public Tile getTile() {
        return tile;
    }

    /**
     * Sets tile this tileReference represents.
     *
     * @param tile the tile
     */
    public void setTile(Tile tile) {
        this.tile = tile;
    }
}