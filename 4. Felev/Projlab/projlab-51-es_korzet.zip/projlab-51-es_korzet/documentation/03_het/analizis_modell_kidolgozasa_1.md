# 3.  Analízis modell kidolgozása

## 3.1  Objektum katalógus

### 3.1.1  Sarkkutató

Meg képes nézni, hogy az előtte lévő jégtáblára hány ember képes felmenni. Képes tárgyakat felvenni, használni. Képes mozogni a pályán, ha beleesik a vízbe, akkor képes meghalni.

### 3.1.2  Eszkimó 

Képes iglut építeni. Képes tárgyakat felvenni, használni. Képes mozogni a pályán, ha beleesik a vízbe, akkor képes meghalni.

### 3.1.3 Jégmező

Jégmezőket tartalmaz.

### 3.1.4 Jégtábla

Képesek rajta Sarkkutatók, Eszkimók, és tárgyak lenni. Lehet benne befagyott tárgy. Van rajta hó, ami alatt a befagyott tárgyak nem látszódnak. Lehet stabil és instabil is, az instabil fel tud borulni, ha túl sok ember lép rá egyszerre.

### 3.1.5 Iglu

Olyan jégtábla, amire hogyha rálép egy Eszkimó vagy Sarkkutató, akkor nem hat rá a hóvihar.

### 3.1.6 Búvárruha

Használatával egy Eszkimó vagy Sarkkutató kibírja vízben halál nélkül

### 3.1.6 Csákány

Használatával gyorsabban lehet kiásni tárgyakat Jégből

### 3.1.6 Élelem

Használatával visszaszerezhet egy hőt egy Eszkimó vagy Sarkkutató

### 3.1.6 Hóvihar

A jégtáblán megy random irányokba, ha olyan jégre megy, ahol van egy Sarkkutató vagy Eszkimó, akkor eggyel csökkenti a testhőjüket

### 3.1.6 Jelzőpisztoly

Használatával megnyerik a játékot

### 3.1.6 Jelzőpisztoly alkatrész

Ha mindegyik egy helyen van, akkor meg lehet építeni a jelzőpisztolyt.

### 3.1.6 Kötél

Használatával ki lehet húzni egy Eszkimót vagy Sarkkutatót a vízből

### 3.1.6 Lapát

Használatával több havat lehet eltakarítani ugyanannyi munkával.

### 3.1.6 Tenger

Eszkimók vagy Sarkkutatók meghalnak, ha beleesnek.

## 3.2 Statikus struktúra diagramok

## 3.3  Osztályok leírása

### 3.3.1  Game

####  Felelősség

Ő irányítja a játékot, vele lehet beregisztrálni játékosokat, és ő felelős minden játékhoz kapcsolódó objektum életéért.

#### Attribútumok

- **map** : Tárolja a Map-et
- **players** : Tárolja a játékosokat

#### Metódusok

- **void Start()**: Elindítja a játékot.
- **void AddPlayer(Player p)**: Hozzáad egy újabb játékost.
- **void Win()**: A játéknak vége: nyertek a játékosok.
- **void Lose()**: A játéknak vége: vesztettek a játékosok.

### 3.3.2  Map

####  Felelősség

Ő felelős a jégtáblák tárolásáért, és irányításáért.

#### Attribútumok

- **stormyIce** : Azon jégtáblák, amiken éppen vihar van.
- **fields** : Az összes jégtábla

#### Metódusok

- **void StartStorm**: Indít egy újabb vihart.
- **void Update()**: Meghívja a fields összes elemén az Update függvényt.

### 3.3.3  Ice

####  Felelősség

Ő felelős azért, hogyha rálép egy Player, akkor lekezelje, hogy beleesett-e vízbe, vagy sem. Felelőssége közé tartozik az is, hogy tároljon egy befagyott Thing-et is, valamint azt ki lehessen szedni, ha 0 a hó szintje.

#### Attribútumok

- **snow** : Megmutatja, hogy hány réteg hó van rajta.
- **isIglu** : Igaz, ha van iglu a táblán.
- **isStormy** : Igaz, ha van vihar a táblán.
- **isHole** : Igaz, ha van lyuk a táblán.
- **maxNumberOfPlayers** : Hány Player lehet rajta maximum.

#### Metódusok

- **void StepOn(Player p)**: Az adott Player rálépett a táblára. 
- **int GetSnow()**: Visszatér a snow értékével.
- **void SetSnow(int snow)**: Beállítja a snow értékét.
- **void Update()**: Frissíti a jégtáblát, ha vihar van rajta, akkor csökenti a playerek életét, stb.
- **void StepOff(Player p)**: Lelép a Player a tábláról.
- **void SetIglu()**: Igazra állítja az isIglu értékét.
- **Thing GetFrozenThing()**: Visszatér a Thing-gel, amit eltárol a Tábla, valamint törli a Táblából. Ha nem 0 a hó szntje, akkor Exception-t dob.
- **int GetMaxNumberOfPlayers()**: Visszatér a maxNumberOfPlayers attribútum értékével.

### 3.3.4  Player

####  Felelősség

Menedzseli egy játékos életciklusát. Tud mozogni, tárgyakat felvenni és eldobni. Tud ásni, és tárgyakat használni. Egy játékost reprezentál a játék modelljében.

#### Attribútumok

- **bodyTemperature** : A játékosnak a teshőhje.
- **isInWater** : igaz, ha a Player egy olyan táblán van, ami lyuk.
- **facing** : Melyik irányba néz jelenleg.
- **hasSwimmingSuit** : Van-e SwimmingSuit tárgya. Ha igen, akkor nem hal meg a vízben.

#### Metódusok

- **void DoAbilty()**: Elvégzi a Player különleges képességét.
- **void ThrowThing(int index)**: Eldobja az index-edik Thing-et a Player backpack-jéből arra a táblára, amelyiken jelenleg áll.
- **void Move(Direction d)** : Elmozog ebben az irányban.
- **bool IsAlive()** : Visszatér igazzal vagy hasimmal, attól függően, hogy a Player jelenleg életben van-e.
- **void SetIsInWater(bool b)** : Beállítja, az isInWater attribútum értékét.
- **void SetHasSwimmingSuit()** : Igazra állítja a hasSwimmingSuit attribútum értékét.
- **void IncrementTemperature()** : Növeli a bodyTemperature attriubútum értékét eggyel. 
- **void DecrementTemperature()** : Csökkenti a bodyTemperature attriubútum értékét eggyel.
- **Ice GetIceInFrontOf()** : Visszatér azzal az Ice objektummal, ami pontosan a Player előtt van.
- **void PickUp()** : Ha van a jégtáblán Thing, akkor beteszi a backpack-jébe.

### 3.3.5  Eskimo

####  Felelősség

Olyan mint a Player, csak a különleges képessége egy iglu lerakása

####  Ősosztályok

Player

#### Metódusok

- **void DoAbilty()**: Elvégzi a Player különleges képességét.

### 3.3.6  Scientist

####  Felelősség

Olyan mint a Player, csak a különleges képessége, hogy megnézheti, hogy az előtte lévő táblára hányan mehetnek fel.

####  Ősosztályok

Player

#### Metódusok

- **void DoAbilty()**: Elvégzi a Player különleges képességét.

### 3.3.7  Thing

####  Felelősség

Reprezentál egy tárgyat, ami vagy erősíti a Player-t, vagy lehet használni.

#### Metódusok

- **void Use(Player p)**: A tárgy használata.
- **void Take(Player p)**: A tárgy felvétele.

### 3.3.8  SwimmingSuit

####  Felelősség

Megvédi a Playert

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Nem csinál semmit.
- **void Take(Player p)**: Meghívja a Player.SetHasSwimmingSuit() függvényét.

### 3.3.9  Shovel

####  Felelősség

2 havat ás egy tábláról.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Kiás 2 havat a Player előtti tábláról.
- **void Take(Player p)**: Nem csinál semmit.

### 3.3.10  Rope

####  Felelősség

Segítségével ki lehet húzni Playereket.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Megnézi, hogy a Player előtt van-e olyan tábla, ami lyuk, és belesett egy Player, ha igen, akkor kihőzza.
- **void Take(Player p)**: Nem csinál semmit.

### 3.3.11  GunPart

####  Felelősség

A Gun-hoz szükséges részek.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Megnézi, hogy megvan-e mindegyik part, ha igen, akkor létrehoz egy Gun-t, és törli az összes GunPart objektumot.
- **void Take(Player p)**: Nem csinál semmit.

### 3.3.12  Pickaxe

####  Felelősség

Használatával gyorsabban ki lehet ásni a Player előtt lévő tárgyat.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Kiássa a Player előtt lévő jégtáblában lévő tárgyat.
- **void Take(Player p)**: Nem csinál semmit.

### 3.3.13  Gun

####  Felelősség

Ha használja a Player, akkor megnyerték a játékot.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Meghívja a Game.Win() függvényt.
- **void Take(Player p)**: Nem csinál semmit

### 3.3.14  Food

####  Felelősség

Egy olyan Thing, amit ha megeszik a Player, akkor növekszik a temperature-je.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Növekszik a Player temperature-je.
- **void Take(Player p)**: Nem csinál semmit.

## 1.4 Szekvencia diagramok

- SwimmingSuit.Use              - kész
- Shovel.Use                    - kész
- Rope.Use                      - kész
- GunPart.Use                   - kész
- Pickaxe.Use                   - kész
- Gun.Use                       - kész
- Food.Use                      - kész
- SwimmingSuit.Take             - kész
- Shovel.Take                   - kész
- Rope.Take                     - kész
- GunPart.Take                  - kész
- Pickaxe.Take                  - kész
- Gun.Take                      - kész
- Food.Take                     - kész
- Player.GetIceInFrontOf        - kész
- Player.Move to Stable Ice     
- Player.Move to Unstable Ice   
- Player.PickUp                 - kész
- Map.Update                    - Kész
- Map.StartStorm                - kész
- Eskimo.DoAbility              - kész
- Scientist.DoAbility           - kész
- Game.Start                    - kész
- Game.AddPlayer                - kész
- Ice.GetFrozenThings           - kész

## 1.6 Napló

| Kezdet | Időtartam | Résztvevők | Leírás |
| --- | --- | --- | --- |
| 2020.02.28. 16:00 | 2 óra | Agócs, Jánoki, Zavada | Értekezlet.Döntés: Zavada elkészíti az osztálydiagramot, a többiek a use-case leírásokat és a szekvencia-diagramokat. |
| 2010.02.29. 17:00 | 5 óra | Zavada | Tevékenység: Elkészíti az osztálydiagramot. |
| 2010.03.01. 16:00 | 3 óra | Zavada | Tevékenység: Elkészíti az szekvencia-diagramok egy részét. |
| 2010.03.01. 20:00 | 2 óra | Agócs | Tevékenység: Elkészíti az maradék szekvencia-diagram egy részét. |
| … | … | … | … |
