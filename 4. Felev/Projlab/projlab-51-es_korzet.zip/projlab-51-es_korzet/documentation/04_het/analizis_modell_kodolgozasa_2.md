# 4.  Analízis modell kidolgozása

## 4.1  Objektum katalógus

### 4.1.1  Sarkkutató

Meg képes nézni, hogy az előtte lévő jégtáblára hány ember képes felmenni. Képes tárgyakat felvenni, használni. Képes mozogni a pályán, ha beleesik a vízbe, akkor képes meghalni.

### 4.1.2  Eszkimó 

Képes iglut építeni. Képes tárgyakat felvenni, használni. Képes mozogni a pályán, ha beleesik a vízbe, akkor képes meghalni.

### 4.1.3 Jégmező

Jégmezőket tartalmaz.

### 4.1.4 Jégtábla

Képesek rajta Sarkkutatók, Eszkimók, és tárgyak lenni. Lehet benne befagyott tárgy. Van rajta hó, ami alatt a befagyott tárgyak nem látszódnak. Lehet stabil és instabil is, az instabil fel tud borulni, ha túl sok ember lép rá egyszerre.

### 4.1.5 Iglu

Olyan jégtábla, amire hogyha rálép egy Eszkimó vagy Sarkkutató, akkor nem hat rá a hóvihar.

### 4.1.6 Búvárruha

Használatával egy Eszkimó vagy Sarkkutató kibírja vízben halál nélkül

### 4.1.6 Csákány

Használatával gyorsabban lehet kiásni tárgyakat Jégből

### 4.1.6 Élelem

Használatával visszaszerezhet egy hőt egy Eszkimó vagy Sarkkutató

### 4.1.6 Hóvihar

A jégtáblán megy random irányokba, ha olyan jégre megy, ahol van egy Sarkkutató vagy Eszkimó, akkor eggyel csökkenti a testhőjüket

### 4.1.6 Jelzőpisztoly

Használatával megnyerik a játékot

### 4.1.6 Jelzőpisztoly alkatrész

Ha mindegyik egy helyen van, akkor meg lehet építeni a jelzőpisztolyt.

### 4.1.6 Kötél

Használatával ki lehet húzni egy Eszkimót vagy Sarkkutatót a vízből

### 4.1.6 Lapát

Használatával több havat lehet eltakarítani ugyanannyi munkával.

### 4.1.6 Tenger

Eszkimók vagy Sarkkutatók meghalnak, ha beleesnek.

## 4.2 Statikus struktúra diagramok

## 4.3  Osztályok leírása

### 4.3.1  Game

####  Felelősség

Ő irányítja a játékot, vele lehet beregisztrálni játékosokat, és ő felelős minden játékhoz kapcsolódó objektum életéért.

#### Attribútumok

- **map** : Tárolja a Map-et
- **players** : Tárolja a játékosokat

#### Metódusok

- **void Start()**: Elindítja a játékot.
- **void AddPlayer(Player p)**: Hozzáad egy újabb játékost.
- **void Win()**: A játéknak vége: nyertek a játékosok.
- **void Lose()**: A játéknak vége: vesztettek a játékosok.

### 4.3.2  Map

####  Felelősség

Ő felelős a jégtáblák tárolásáért, és irányításáért.

#### Attribútumok

- **stormyIce** : Azon jégtáblák, amiken éppen vihar van.
- **fields** : Az összes jégtábla

#### Metódusok

- **void StartStorm**: Indít egy újabb vihart.
- **void Update()**: Meghívja a fields összes elemén az Update függvényt.

### 4.3.3  Tile

####  Felelősség

Ő felelős azért, hogyha rálép egy Player, akkor lekezelje, hogy beleesett-e vízbe, vagy sem. Felelőssége közé tartozik az is, hogy tároljon egy befagyott Thing-et is, valamint azt ki lehessen szedni, ha 0 a hó szintje.

#### Attribútumok

- **snow** : Megmutatja, hogy hány réteg hó van rajta.
- **iglu** : Igaz, ha van iglu a táblán.
- **isStormy** : Igaz, ha van vihar a táblán.
- **neighbours** : A szomszédos Tile-ok
- **frozenThing** : A befagyott tárgy, ha létezik
- **things** : a rajta lévő dolgok

#### Metódusok

- **void StepOn(Player p)**: Az adott Player rálépett a táblára. 
- **void Update()**: Frissíti a jégtáblát, ha vihar van rajta, akkor csökenti a playerek életét, stb.
- **void StepOff(Player p)**: Lelép a Player a tábláról.
- **int GetMaxNumberOfPlayers()**: Visszatér a maxNumberOfPlayers attribútum értékével.
- **int BuildIglu()**: Átállítja az iglu értékét igazra.
- **int GetIceInDirection()**: Visszatér a direction irányában lévő szomszéddal.

### 4.3.4  Player

####  Felelősség

Menedzseli egy játékos életciklusát. Tud mozogni, tárgyakat felvenni és eldobni. Tud ásni, és tárgyakat használni. Egy játékost reprezentál a játék modelljében.

#### Attribútumok

- **isInWater** : igaz, ha a Player egy olyan táblán van, ami lyuk.
- **enegy** : Mennyi energiája van még
- **alive** : Életben van-e még.

#### Metódusok

- **void DoAbilty()**: Elvégzi a Player különleges képességét.
- **void ThrowThing(int index)**: Eldobja az index-edik Thing-et a Player backpack-jéből arra a táblára, amelyiken jelenleg áll.
- **void Move(Direction d)** : Elmozog ebben az irányban.
- **Ice GetIceInDirection(Direction d)** : Visszatér azzal az Ice objektummal, ami pontosan a Player előtt van.
- **void PickUp()** : Ha van a jégtáblán Thing, akkor beteszi a backpack-jébe.
- **Dig()** : Kiássa a szemben lévő tile-t.
- **Shovel()** : Kiássa a szemben lévő tile hóját.

### 4.3.5  Eskimo

####  Felelősség

Olyan mint a Player, csak a különleges képessége egy iglu lerakása

####  Ősosztályok

Player

#### Metódusok

- **void DoAbilty()**: Elvégzi a Player különleges képességét.

### 4.3.6  Scientist

####  Felelősség

Olyan mint a Player, csak a különleges képessége, hogy megnézheti, hogy az előtte lévő táblára hányan mehetnek fel.

####  Ősosztályok

Player

#### Metódusok

- **void DoAbilty()**: Elvégzi a Player különleges képességét.

### 4.3.7  Thing

####  Felelősség

Reprezentál egy tárgyat, ami vagy erősíti a Player-t, vagy lehet használni.

#### Metódusok

- **void Use(Player p)**: A tárgy használata.
- **void ApplyEffects(Stats s)**: A tárgy effektjeivel átállítja a Stats értékét.

### 4.3.8  SwimmingSuit

####  Felelősség

Megvédi a Playert

####  Ősosztályok

Thing

#### Metódusok

- **void ApplyEffects(Stats s)**: A tárgy effektjeivel átállítja a Stats értékét.

### 4.3.9  Shovel

####  Felelősség

2 havat ás egy tábláról.

####  Ősosztályok

Thing

#### Metódusok

- **void ApplyEffects(Stats s)**: A tárgy effektjeivel átállítja a Stats értékét.

### 4.3.10  Rope

####  Felelősség

Segítségével ki lehet húzni Playereket.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Megnézi, hogy a Player előtt van-e olyan tábla, ami lyuk, és belesett egy Player, ha igen, akkor kihúzza.

### 4.3.11  GunPart

####  Felelősség

A Gun-hoz szükséges részek.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Megnézi, hogy megvan-e mindegyik part, ha igen, akkor létrehoz egy Gun-t, és törli az összes GunPart objektumot.

### 4.3.12  Pickaxe

####  Felelősség

Használatával gyorsabban ki lehet ásni a Player előtt lévő tárgyat.

####  Ősosztályok

Thing

#### Metódusok

- **void ApplyEffects(Stats s)**: A tárgy effektjeivel átállítja a Stats értékét.

### 4.3.13  Gun

####  Felelősség

Ha használja a Player, akkor megnyerték a játékot.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Meghívja a Game.Win() függvényt.

### 4.3.14  Food

####  Felelősség

Egy olyan Thing, amit ha megeszik a Player, akkor növekszik a temperature-je.

####  Ősosztályok

Thing

#### Metódusok

- **void Use(Player p)**: Növekszik a Player temperature-je.

### 4.3.14  Hole

####  Felelősség

Egy olyan Tile, amire ha rálép egy Player, akkor beleesik a vízbe.

####  Ősosztályok

Tile

#### Metódusok

- **int GetMaxNumberOfPlayers**: 0-val tér vissza.
- **void StepOn(Player p)**: Vízbe esik az adott Player.

### 4.3.14  StableIce

####  Felelősség

Egy olyan Tile, amire ha rálép egy Player, akkor nem esik bele a vízbe.

####  Ősosztályok

Tile

#### Metódusok

- **int GetMaxNumberOfPlayers**: -1-el tér vissza.
- **void StepOn(Player p)**: Rélép az adott Player

### 4.3.14  UnstableIce

####  Felelősség

Egy olyan Tile, amire ha rálép egy Player, akkor beleeshet a vízbe.

####  Ősosztályok

Tile

#### Attribútumok

- **maxNumberOfPlayers** : Ahány Player lehet rajta egyszerre

#### Metódusok

- **int GetMaxNumberOfPlayers**: Annyival tér vissza, ahány Player lehet rajta.
- **void StepOn(Player p)**: Ha túl  sokan vannak rajta, akkor vízbe esik az adott Player.

## 4.4 Szekvencia diagramok



## 4.5 Napló

| Kezdet | Időtartam | Résztvevők | Leírás |
| --- | --- | --- | --- |
| 2020.03.07. 16:00 | 5 óra | Mindenki | Értekezlet.Döntés: Agócs és Ritgasszer befejezi az osztálydiagrammot, és a szekvencia-diagrammokat. |
| 2020.03.08. 16:00 | 2 óra | Agócs és Ritgasszer | Osztálydiagramm befejezése. |
| 2020.03.08. 16:00 | 2 óra | Agócs és Ritgasszer | Szekvencia-diagrammok befejezése. |
| … | … | … | … |
