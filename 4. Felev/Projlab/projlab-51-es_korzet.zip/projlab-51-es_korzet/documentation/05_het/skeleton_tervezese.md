# 5. Szkeleton tervezése

## 1.1 A szkeleton modell valóságos use-case-ei

[A szkeletonnak, mint önálló programnak a működésével kapcsolatos use-case-ek.]

### 1.1.1 Use-case diagram

### 1.1.2 Use-case leírások

[Minden use-case-hez külön]

| Move |   |
| --- | --- |
| Rövid leírás |   |
| Aktorok |   |
| Forgatókönyv |   |


| Lose |   |
| --- | --- |
| Rövid leírás | A játéknak vége és nem sikerült megmenekülniük  |
| Aktorok | Controll  |
| Forgatókönyv | Akkor következik be ha valamelyik játékos meghal   |


| Win |   |
| --- | --- |
| _Rövid leírás_ | A játéknak vége és sikerült megmenekülnie mindenkinek  |
| _Aktorok_ | Controll  |
| _Forgatókönyv_ | Akkor következik be ha valamennyi játékos egy mezőn van  és az összerakott pisztolyt használják|

| Use item |   |
| --- | --- |
| _Rövid leírás_ | Egy tárgy (Rope, GunPart, Gun, Food) használata |
| _Aktorok_ | Player  |
| _Forgatókönyv_ | Kötél esetén kihúz egy másik embert a vízből. Pisztolyalkatrész esetén ha megvan az összes rész akkor összerakja a pisztolyt. Pisztoly esetén ez annak elsütését jelenti. Étel esetén vagy nő a testhő, vagy ha az max akkor a következőnek végezhető munka. |

## 1.2 A szkeleton kezelői felületének terve, dialógusok

A szkeleton kezelőfelülete egy consolos felület ahol szövegs parancsokkal és szöveges menüvel lesz megoldva a vezérlés. Lesz egy kiindulási menü, hol ki kell választani egy listából azt a szekvenciát, amit ki akarunk próbálni.

Amikor már ki lett választva egy szekvencia, amit le akarunk tesztelni, akkor jöhetnek fel eldöntendő kérdések a kiválasztott szekvenciától függően (például, hogy stabil jégre, instabil jégre vagy lyukra akarunk lépni). Az eldöntendő kérdésekre a választ szintén egy felsorolásból lehet kiválasztani.

Egy kiválasztott szekvenci kiírja a függvényhívásokat. Fentről lefelé tellik az idő. A függvényhívások kiírásak szerepel az osztály neve amihez tartozik a függvény, a függvény neve, a függvény paraméterei és a visszatérési értékének típusa (az utóbbi csak akkor, ha nem void), valamint azt, hogy ki hívja az adott függvényt.

## 1.3 Szekvencia diagramok a belső működésre

[A szkeletonban implementált szekvenciadiagramok. Tipikusan egy use-case egy diagram. Ezek megegyezhetnek a korábban specifikált diagramokkal, de az egyes életvonalakat (lifeline) egyértelműen a szkeletonban példányosított objektumokhoz kell tudni kötni. Azt kell megjeleníteni, hogy a szkeletonban létrehozott objektumok egymással hogyan fognak kommunikálni.]

## 1.4 Kommunikációs diagramok

[A szkeletonban, az egyes szkeleton-use-case-ek futása során létrehozott objektumok és kapcsolataik bemutatására szolgáló diagramok. Ezek alapján valósítják meg a szkeleton fejlesztői az inicializáló kódrészleteket.]



## 1.5 Napló



| Kezdet | Időtartam | Résztvevők | Leírás |
| --- | --- | --- | --- |
| 2010.03.21. 18:00 | 2,5 óra | HorváthNémethTóthOláh | Értekezlet.Döntés: Horváth elkészíti az osztálydiagramot, Oláh a use-case leírásokat. |
| 2010.03.23. 23:00 | 5 óra | Németh | Tevékenység: Németh implementálja a tesztelő programokat. |
| … | … | … | … |
