# 2. Követelmény, projekt, funkcionalitás

## 1.1 Bevezetés

### 1.1.1 Cél

A dokumentum leírja a játék követelményeit, a projekt tervét és egy összefoglaló képet ad a játékról a megvalósítás részletei nélkül.

### 1.1.2 Szakterület

Szórakoztató célra készült stratégiai játék mindenki számára.

### 1.1.3 Definíciók, rövidítések

BME HSZK - Budapesti Műszaki Egyetem Hallgatói számítógép Központ

### 1.1.4 Hivatkozások

>[Tárgyhonlap](https://www.iit.bme.hu/oktatas/tanszeki_targyak/BMEVIIIAB02)

### 1.1.5 Összefoglalás

A dokumentum magában foglalja a követelményeket és a use-case-eket. Ad egy képet a projekt menetéről.

## 1.2 Áttekintés

### 1.2.1 Általános áttekintés

A szoftver objektum orientált elveket követ. Ennek megfelelően minden megvalósításáért egyetlen objektum felelős úgy hogy az azonos tulajdonsággal rendelkezőket interfacek alá gyűjtjük. Nincsen egy mindent irányító objektum. Egy adatszerkezet felel a jégmezőért amin az egyes objektumok elvégzik a feladataikat. A lehető legtöbb mindent interfacekkel csinálunk, hogy azokat csak meg kelljen valósítani az egyéb objektumoknak. A fontosabb rendszerek a jégtábla, a szereplők és a tárgyak.

### 1.2.2 Funkciók

Egy jégmező a játék helyszíne amit tenger vesz körbe. A cél a szabadulás. A jégmezőt jégtáblák alkotják rácsos elhelyezkedésben, amiknek vannak egyedi tulajdonságaik. Ilyen egyedi tulajdonság az, hogy stabil a jégtábla vagy instabil. A stabil táblák akárhány embert elbírnak, viszont az instabilok egy adott fő fölött beleborulnak a tengerbe és a szereplők beleesnek a vízbe. A jégtáblákat a játék kezdetén eltérő mennyiségű hó borítja, ami változhat a játék folyamán.

Az egyes jégtáblákba különféle tárgyak lehetnek belefagyva. Ilyen tárgy a lapát, a kötél, a búvárruha, az élelem, csákány és az alkatrészek egy jelzőpisztolyhoz. Befagyott tárgyat csak akkor lehet meglátni és kiásni, ha a jégtáblán nincsen hó. Ez alapján a tárgyak a hó alatt nem látszanak, a havat le kell róla takarítani. Két jégtábla között lehetnek lyukak, amik nem látszanak mert hó van rajtuk. Ha valaki beleesik egy ilyen lyukba, akkor meghal, hacsak nincs rajta búvárruha, vagy nincs a szomszéd táblán egy másik játékos kötéllel, aki rögtön (a következő körében a szomszédos embernek) a segítségére siet.

A játék körökre van osztva, egy körben a szereplők adott sorrendben követik egymást. Egy szereplő egy körben 4 egységnyi munkát végezhet. Egy egységnyi munka alatt át lehet menni egy szomszédos táblára, el lehet takarítani egy egységnyi havat arról a tábláról ahol a szereplő áll és egy már kiásott tárgyat fel lehet venni. Egy egységnyi munka alatt minden szereplő használhatja a képességét. Egy tárgy kiásásához, ha már nincs hó a táblán 2 egység szükséges. A jégmezőn időnként feltámad a hóvihar, és néhány érintett jégtáblát újabb adag friss hóval borít be. Azok akik a szabadban (nem igluban) vannak a hóvihar idején, azoknak a testhője egy egységgel csökken. Az eszkimóknak a játék elején 5 egység testhője van, a sarkkutatónak csak 4. Egy élelem elfogyasztása eggyel növeli a testhőt, viszont az étkezés az étel megszerzése után egy egységnyi munkába merül. Egy körben ha valakinek maxon van a testhője és úgy eszik, akkor a következő körben eggyel több (5) egységnyi munkát végezhet (ez nem halmozható). Az eszkimó által épített iglut használhatja a sarkkutató is, egy megépített iglu nem rombolódik le, vagyis a későbbiekben is lehet használni.

A sarkkutató képessége, hogy egy munkával meg tudja nézni, hogy az a jégtábla, amire lépne, hány embert bír el (a lyuk egyet sem). Az eszkimóé, hogy tud iglut építeni egy munkaért, amiben átvészelhetők a hóviharok. Az igluk nagyjából olyan súlyúak mint egy ember, így ez is beleszámolódik abba, hogy egy jégtábla mennyi embert bír el (Pl.: ha csak egy embert, és az eszkimó épít rá, akkor a jégtábla felborul és vízbe esik). Egy vízbe esett ember ha kimentik akkor 1 testhővel folytatja a játékot és elveszíti minden tárgyát a búvárruhán kívül. 

A játék során a jégbefagyott eszközök segítik a szereplőket. A lapáttal egységnyi munkával két egységnyi havat lehet eltakarítani. A kötéllel egy az előző körben vízbe esett embert lehet kimenteni egy szomszédos mezőről, ennek használata egységnyi munkába kerül. A búvárruhát viselő emberek ha beleesnek a vízbe nem halnak meg röktön, körönként egy egységgel csökken a testhőjük, ezidő alatt odaérhet egy köteles társuk, hogy kimentse őket (ha a következő körben menekülnek akkor nem csökken a hőmérsékletük), nem tudnak maguktól kimászni a vízből. A kimentett játékos a kimentő játékos helyére kerül, a kimentő játékos pedig eggyel hátrébb. Ha hátrébb nem kerülhet, akkor balra vagy jobbra, ha oda sem, akkor pedig nem lehet kimenteni. A csákánnyal két egységnyi munka helyett egy egységnyivel kiszedhetőek a tárgyak a jégből.

A játék célja egy jelzőrakéta alkatrészeinek (pisztoly, jelzőfény, patron) megtalálása. Az alkatrészek is bele vannak fagyva a jégbe. Ha ezeket a csapat összegyűjti és ugyanarra a jégtáblára viszi, akkor egy munka felhasználásával összeszerelhetik és elsüthetik. Ez a játék végét jelenti és a szereplők megmenekülnek. Ez csak akkor valósulhat meg, ha mindannyian ugyanazon a táblán vannak, vagyis ha már egy ember meghal, akkor elvesztették a játékot és a játék véget ér.

### 1.2.3 Felhasználók

A felhasználóknak nem kell semmilyen előismeret a játék játszásához. Egyszerűen tudnak lépni. A kezelőfelület egyértelmű, nem igényel semmilyen előismeretet.

### 1.2.4 Korlátozások

A szoftver csak a Java futtatókörnyezetet használkatja, külső csomagokat nem tölthet be.

### 1.2.5 Feltételezések, kapcsolatok

A tárgyhonlapon megadott feladatkiírás az alapja a megoldásnak. Az lett kiegészítve és zárt rendszerré alakítva.

## 1.3 Követelmények

### 1.3.1 Funkcionális követelmények

| Azonosító | Leírás | Ellenőrzés | Prioritás | Forrás | Use-case | Komment |
| --- | --- | --- | --- | --- | --- | --- |
| fk1  | Szereplő átlép egy szomszédos táblára  |bemutatás   |alapvető   |feladatkiírás   | Move  |   |
| fk2  |Egy birtokolt tárgy használata   |bemutatás   |alapvető   | feladatkiírás  | Use item  |    |
| fk3  |Egy szereplő használja a képességét   |bemutatás   | alapvető  |feladatkiírás   | Use skill  |   |
| fk4  |A vihar havat hord a táblákra   |kiértékelés   |alapvető   | feladatkiírás  | Storm  |   |
| fk5  |Egy személy ellapátol egy egységnyi havat   | bemutatás   | alapvető  | feladatkiírás  | Clear  |   |
| fk6  |Egy személy kiás egy tárgyat   | bemutatás  | alapvető  | csapat  |Dig   |   |
| fk7  | Egy személy felvesz egy tárgyat  |bemutatás   |alapvető   | feladatkiírás  | Collect item  |   |
| fk8  |Egy személy beleesik egy lyukba   |bemutatás   |  alapvető | feladatkiírás  | Fall  |   |
| fk9  |Egy tábla beleesik a vízbe a túlsúly miatt   |kiértékelés   | alapvető  | feladatkiírás  |Collapse   |   |
| fk10  |A játékosok a jelzőrakéta használata után nyernek   | bemutatás  | alapvető  |feladatkiírás   | Use item  |   |
| fk11  |Csökken vihar idején a szabadon levők hője   | kiértékelés  | fontos  |feladatkiírás   | Storm  |   |
| fk12  |Búvárruhás ember testhője nem csökken le rögtön a vízben   |  kiértékelés  |opcionális   |csapat   |Use item   ||
| fk13  | Kihúznak valakit a vízből kötéllel  |bemutatás   |fontos   |feladatkiírás   | Use item  |   |
| fk14  | Lapáttal gyorsabb a hóelhordás  |kiértékelés   | opcionális  | feladatkiírás  | Use item  |   |
| fk15  | Csákánnyal gyorsabb az ásás  | kiértékelés   |opcionális   | csapat  | Use item  |   |
| fk16  | Evésre nő a testhő  | kiértékelés  | fontos  | feladatkiírás  | Use item  |   |
| fk17  |Maxos teshővel evésre több munkát lehet végezni a következő körbe   | kiértékelés  | opcionális  | csapat  |Use item   |   |
| fk18  |Elsütik a jelzőrakétát   | bemutatás  |fontos   | feladatkiírás  | Use item  |   |
| fk19  | Egy ember átvészeli a vihart igluban   |kiértékelés   |fontos   | feladatkiírás  |Storm   |   |

### 1.3.2 Erőforrásokkal kapcsolatos követelmények

| Azonosító | Leírás | Ellenőrzés | Prioritás | Forrás | Komment |
| --- | --- | --- | --- | --- | --- |
|  e1|  HSZK-ban található, vagy annál jobb PC|   tesztelés|   alapvető| feladatkiírás|   -|
|e2|Legalább 1280x720 felbontású monitos|  tesztelés|  alapvető| csapat| - |

### 1.3.3 Átadással kapcsolatos követelmények
### TODO: ez így nem jó ###
| Azonosító | Leírás | Ellenőrzés | Prioritás | Forrás | Komment |
| --- | --- | --- | --- | --- | --- |
|   a1|   Csapatok regisztrációja|   bemutatás|   alapvető|   feladatkiírás|   határidő: február 16|
|   a2| Követelmény, projekt, funkcionalitás|   bemutatás|  alapvető|   feladatkiírás|  határidő: február 24|
|   a3|   Analízis modell kidolgozása 1.|   bemutatás|   alapvető|   feladatkiírás|   határidő: március 2|
|   a4|   Analízis modell kidolgozása 2.|   bemutatás|   alapvető|   feladatkiírás|   határidő: március 9|
|   a5|   Szkeleton tervezése|   bemutatás|   alapvető|   feladatkiírás|   határidő: március 16|
|   a6|   Szkeleton|   bemutatás|   alapvető|   feladatkiírás|   határidő: március 23|
|   a7|   Prototípus koncepciója|   bemutatás|   alapvető|   feladatkiírás|   határidő: március 30|
|   a8|   Részletes tervek|   bemutatás|   alapvető|   feladatkiírás|   határidő: április 6|
|   a9|   Prototípus készítése, tesztelése|   tesztelés|   alapvető|   feladatkiírás|   határidő: április 20|
|   a10|   Prototípus|   bemutatás|   alapvető|   feladatkiírás|   határidő: április 27|
|   a11|   Grafikus felület specifikációja|   bemutatás|   alapvető|   feladatkiírás|   határidő: május 4|
|   a12|   Grafikus változat készítése|   tesztelés|   alapvető|   feladatkiírás|   határidő: május 11|
|   a13|   Grafikus változat és Összefoglalás|   bemutatás|   alapvető|   feladatkiírás|   határidő: május 18|


### 1.3.4 Egyéb nem funkcionális követelmények

| Azonosító | Leírás | Ellenőrzés | Prioritás | Forrás | Komment |
| --- | --- | --- | --- | --- | --- |
|   n1|  Legyen a felhasználónak számítógépe|   -|   alapvető|   csapat|   |
|   n2|  Legyen a felhasználónak egere|   -|   alapvető|   csapat|   |
|   n3|  Legyen a felhasználónak monitorja|   -|   alapvető|   csapat|   |
|   n4| A felhasználónak legyen alapvető informatikai ismeretei|   -|   alapvető|   csapat|   |

## 1.4 Lényeges use-case-ek

### 1.4.1 Use-case leírások

| Use-case neve | Move  |
| --- | --- |
| Rövid leírás | A játékos lép táblák között  |
| Aktorok |Player, Controll   |
| Forgatókönyv | Egy szereplő egy tábláról átlép a szomszédos táblára  |

| Use-case neve |Use skill   |
| --- | --- |
| Rövid leírás |Használja a játékos a képességét   |
| Aktorok |Player   |
| Forgatókönyv | Felhasználja a képességét egy szereplő  |

| Use-case neve | Use item  |
| --- | --- |
| Rövid leírás |Használ a játékos egy eszközt   |
| Aktorok |Player   |
| Forgatókönyv | A már nálalevő eszközt használja a szereplő  |
| Másodlagos| Ezzel lehet összeszerelni a jelzőpisztoly alkatrészeit  |


| Use-case neve |Storm   |
| --- | --- |
| Rövid leírás |A vihar beborít hóval táblákat   |
| Aktorok | Controll, Player  |
| Forgatókönyv | A vihar lecsap és akiket elkap azok vesztenek életet (testhőt), illetve havat hord a táblákra  |

| Use-case neve | Collapse  |
| --- | --- |
| Rövid leírás | Beleesik a jégtábla a játékossal a vízbe   |
| Aktorok |Controll   |
| Forgatókönyv |  Egy táblán túl sok a játékos és beszakad a vízbe a rajta állókkal |    

| Use-case neve |Clear   |
| --- | --- |
| Rövid leírás |Havat takarít el a tábláról   |
| Aktorok |Player   |
| Forgatókönyv | Eltávolít havat arról a jégtábláról amin áll  |

| Use-case neve |Dig   |
| --- | --- |
| Rövid leírás |Kiás egy tárgyat   |
| Aktorok |Player   |
| Forgatókönyv |  Kiás egy tárgyat a jégből ahol áll |

| Use-case neve |Fall   |
| --- | --- |
| Rövid leírás |A játékos és beleesik a vízbe  |
| Aktorok |Player   |
| Forgatókönyv | Lyukba lép a játékos és beleesik a vízbe  |

| Use-case neve |Collect item   |
| --- | --- |
| Rövid leírás |A játékos felvesz egy tárgyat  |
| Aktorok |Player   |
| Forgatókönyv | Azon a mezőn ahol áll a játékos felvehet egy már kiásott tárgyat  |

### 1.4.2 Use-case diagram
### TODO: leszakadás nem aktor ###
![ucd](https://gitlab.com/agocsdaniel/projlab-51-es_korzet/-/raw/master/02_het/usecasediagramm.jpg "Use-Case Diagram")

## 1.5 Szótár

| Szó |Leírás   |
| --- | --- |
|Átmenni | Egy személy egy tábláról átkerül egy másik táblára  |
|Beleborul | Egy jégtábla a személyekkel rajta beleborul a vízbe, következtébe az emberek vízbe kerülnek  |
|Beleesik | Egy ember a többi embertül függetlenül a vízbe kerül |
|Búvárruha | Egy tárgy, amivel tovább bírja az ember a vízben anélkül, hogy meghalna  |
|Csákány |Egy tárgy amivel gyorsabban lehet tárgyakat kiásni a jégből  |
|Egységnyi munka |Mértékegység, amivel azt mérjük mennyi mindent csinálhat egy ember egy körben  |
|Elbír |Nem borul a vízbe a jégtábla  |
|Élelem |Egy tárgy, amit használva növekszik a testhő |
|Eszkimó |Egy személy, aki tud iglut építeni  |
|Étkezés | Élelem használata |
|Győzelem |A játék vége, úgy, hogy megszabadultak a mezőről  |
|Hóvihar |Következtévben több hó lehet a táblákon és csökkenhet az emberek testhője  |
|Iglu |Védelem a hóvihar előtt  |
|Instabil | Ha valamennyinél többen álnak egy táblán beleborul a vízbe |
|Játék |Addig tart amíg vége nem lesz vagy győzelemmel vagy vereséggel, körökből áll  |
|Játékos köre | Egy ember használhat tárgyakat, képességeketé s lépkedhet adott munkáért |
|Játék vége |Vagy győztek vagy vesztettek  |
|Jégbefagyott |A tárgyat nem lehet felvenni de ott van  |
|Jégmező |Egy jégtáblákból (és lyukakból) álló felület amit tenger határol |
|Jégtábla | Egy része a jégtáblának, független a többitől és vannak saját jellemzői 
|Jelzőpisztoly |A győzelemhez szükséges tárgy |
|Jelzőpisztoly alkatrész |Ezekből lehet összerakni a jelzőpisztolyt, kölön nem jók semmire  |
|Kiásni|Egy tárgyat mostantól fel lehet venni |
|Kiásott tárgy |Egy tárgy amit fel lehet venni  |
|Kimentik |Egy embert kiszed a vízből egy szomszédos mezőn álló ember akinél van kötél  |
|Kör | Minden játékosnak van egy köre fix sorrendben |
|Kötél |Egy tárgy amivel embert lehet menteni a vízből  |
|Következő kör |Amikor először van annak a játékosnak a köre aki kör fix sorrendjét kezdi a mostani játékos köre után  |
|Lapát |Egy tárgy amivel több havat lehet elhordani ugyanannyi munkáért  |
|Lyuk |Egy terület a mezőn ahol nincs jég, a rálépő ember beleesik a vízbe  |
|Meghal |Elfogy a testhője egy embernek  |
|Meglát |Egy tárgy jégtábláján nincsen több hó  |
|Sarkkutató |Egy személy aki meg tudja mondani egy tábláról, hogy mennyi embert bír el  |
|Stabil |Olyan tábla ami tetszőlegesen sok embert elbír  |
|Szabadban |Viharkor nem igluban levő, hat rá a vihar  |
|Szabadulás |Eljutottak a jégmezőről  |
|Szomszéd tábla |Olyan táblák amik összeérnek  |
|Tábla |Jégtábla  |
|Takarít |Eltávolít valamennyi havat egy tábláról  |
|Tárgy |Pozitív hatással van a játék menetére  |
|Tárgy használata |Egy tárgy hatása érvénybelép  |
|Tenger |Az emberekre ártalmas közeg  |
|Testhő |Ha elfogy meghal az ember, evéssel nő |
|Vesztés |Valaki meghal a játékban  |

## 1.6 Projekt terv

A projekt végrehajtásának menete meg fog egyezni a hetente érkező feladatokkal.  Célunk, hogy minden héten a lehető leghamarabb elkészüljünk a feladatokkal, hogy utána a a laborvezetővel konzultálva az esetleges hibákat ki tudjuk javítani. 

Minden héten a munkát egy megbeszéléssel fogjuk kezdeni, mely tulajdonképpen egy SCRUM sprintnek a tervezése. Minden héten más a SCRUM master, viszont ő is kiveszi a részét a munkából.

Csoportmunkát Slack segítségével koordináljuk, a fájlokat Gitlabon valamint Google Drive segítségével osztjuk meg. 

## 1.7 Napló

| Kezdet | Időtartam | Résztvevők | Leírás |
| --- | --- | --- | --- |
| 2020.02.20. 16:00 | 4 óra | Mindenki | Értekezlet. Döntés: A funkcionális követelmények fixálása. Zavada elkészíti az osztálydiagramot.  Pércsi elkészíti a leírást a kiegészítésekkel. Rittgasszer elkészíti a szótárat. Jánoki az átadással kapcsolatos dokumentációt és a funkcionális követelményeket készíti el. Agócs a nem-funkcionális követelményeket és a use-casekhez kapcsolódó dokumentációt. Mindegyik határideje  _2020.02.22. 16:00_ |
| 2010.03.21. 15:00 | 5 óra | Zavada | Tevékenység: Zavada elkészíti és beszúrja a dokumentumba az use-case diagramot. |
| 2010.03.21. 15:00 | 5 óra | Agócs| Tevékenység: Agócs elkészíti és beszúrja a dokumentumba use-casekhez kapcsolódó dokumentációt. |
| 2010.03.22. 12:00 | 5 óra | Jánoki| Tevékenység: Jánoki elkészíti és beszúrja a dokumentumba az átadással kapcsolatos dokumentációt és a funkcionális követelményeket |
| 2010.03.23. 12:00 | 5 óra | Pércsi| Tevékenység: Pércsi elkészíti és beszúrja a dokumentumba a leírást |
| 2010.03.23. 14:00 | 5 óra | Rittgasszer | Tevékenység: Rittgasszer elkészíti és beszúrja a dokumentumba a szótárat|
| … | … | … | … |
