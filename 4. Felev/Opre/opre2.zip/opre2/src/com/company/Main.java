package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

class Keret
{
    public Keret(char n)
    {
        nev = n;
        lap = -1;
        hasznalt = false;
    }
    public char nev;
    public int lap;
    public boolean hasznalt;
}


public class Main
{

    static char algorithm(List<Keret> keretek, int lap)
    {
        for(int idx = 0; idx < keretek.size(); ++idx)
        {
            if (keretek.get(idx).lap == lap)
            {
                keretek.get(idx).hasznalt = true;
                return '-';
            }
        }



        for(int idx = 0; idx < keretek.size(); ++idx)
        {
            if (keretek.get(idx).lap == -1)
            {
                keretek.get(idx).lap = lap;
                return keretek.get(idx).nev;
            }
        }


        for (int idx = 0; idx < keretek.size(); ++idx)
        {
            Keret tmp = keretek.get(0);
            for(int i = 0; i < keretek.size() - 1; ++i)
            {
                keretek.set(i, keretek.get(i + 1));
            }
            keretek.set(keretek.size() - 1, tmp);

            if(keretek.get(keretek.size() - 1).hasznalt)
            {
                keretek.get(keretek.size() - 1).hasznalt = false;

                continue;
            }else
            {
                keretek.get(keretek.size() - 1).lap = lap;

                return keretek.get(keretek.size() - 1).nev;
            }
        }

        return '*';
    }

    static  List<Integer> Read() throws IOException
    {
        String inputText = "";

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int i;
        while((i = br.read()) != -1)
        {
            if((i <= (int) '9' && i >= (int) '0') || i == (int)',')
                inputText += (char) i;
        }

        br.close();

        List<Integer> input = new ArrayList<>();

        String[] splitted = inputText.split(",");;

        for(int idx = 0; idx < splitted.length; ++idx)
            input.add(Integer.parseInt(splitted[idx]));

        return input;
    }


    public static void main(String[] args) throws IOException
    {
        int n = 4;

        List<Keret> keretek = new ArrayList<>();
        List<Integer> input;
        input = Read();
        //input = Arrays.asList(1,2,3,4,1,5,1);


        for(int idx = 0; idx < n; ++idx)
            keretek.add(new Keret((char)((int)'A' + idx)));




        List<Keret> fifo = keretek;
        int laphiba = 0;
        String output = "";

        for(int idx = 0; idx < input.size(); ++idx)
        {
            char result = algorithm(fifo, input.get(idx));
            if(result != '-')
                ++laphiba;
            output += result;
        }

        System.out.println(output);
        System.out.println(laphiba);
    }
}
